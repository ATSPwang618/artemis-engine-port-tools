# 包文件

将游戏数据整合到一个文件中称为包文件。其扩展名为 .pfs。

使用 Tools 文件夹中的 GeneratePackFile2.exe 来创建。

Artemis Engine 将包文件中整合的文件视为普通文件。

但是，以下文件是例外，不能包含在包文件中：

- MJA 以外的视频文件（Android 除外）-> 用于全屏播放的视频文件（如 .mp4）
- 包文件 -> 嵌套的包文件（pfs 中的 pfs）
  

此外，一个包文件的最大大小为2GB。

当 Artemis Engine 查找文件时，
- 普通文件
- 根包文件内的文件
- 包含文件夹路径时，除根包文件外的其他包文件内的文件

将按照以上顺序查找。

根包文件是具有特定名称的包文件，根据平台的不同名称也不同：

- Windows：
  与 exe 同名的包文件（如 Artemis.exe 对应 Artemis.pfs）
  如果不存在，则为 root.pfs
  如果 root.pfs 也不存在，则视为已合并的 exe 和 pfs（特殊格式）

- iOS：
  root.pfs

- Android：
  如果不使用 APK Expansion Files，则为 root.pfs
  如果使用，则根据 APK Expansion Files 规范自动命名（由 Android 自动命名）

- WebAssembly：
  artemis.data

包文件可以包含文件夹，并且可以像文件夹一样处理。

例如，
```
  Artemis.exe
  Artemis.pfs
  image.pfs
  sound.pfs
  chara/
    stand.pfs
    face.pfs
```
文件结构是这样的，
```
  foo.iet -> 在 Artemis.pfs 中的 foo.iet
  image/bar.png -> 在 image.pfs 中的 bar.png
  sound/bgm/hoge.ogg -> 在 sound.pfs 中的 bgm 文件夹内的 hoge.ogg
  chara/stand/fuga.png -> 在 chara 文件夹内的 stand.pfs 中的 fuga.png
  chara/face/large/a.png -> 在 chara 文件夹内的 face.pfs 中的 large 文件夹内的 a.png
```

但是，在性能上考虑，最好只使用根包文件，而不使用其他包文件。

包文件具有补丁机制。

例如，包含 foo.iet、bar.png、hoge.ogg、fuga.png 的包文件 root.pfs 已发布，现在想要修复 foo.iet。

这种情况下，创建一个包含修复后 foo.iet 的包文件 root.pfs.000，并将其保存在与 root.pfs 相同的文件夹中，这样就会优先使用它。

root.pfs.000 称为补丁文件，
可以创建 000 到 999 共1000次补丁。
