# 运行环境与开环境

## 运行环境

这是使用 Artemis Engine 创建的应用程序的运行环境。

### Windows
	可在 XP、Vista、7、8、8.1、10 上运行。
	在除 XP 外的系统中，也可以运行 64 位版本。（但不以 64 位应用程序形式运行）

	然而，在无法使用 Pixel Shader 2.0 的环境中无法运行。

	由于 CPU 和内存等规格要求受分辨率和脚本等因素影响较大，
	请实际运行以确定所需环境。
	但最低要求应该满足 Windows 自身的运行要求。

	作为对低性能环境的检查，
	在御影的环境中，使用了
	- VAIO Type P（Atom 1.33Ghz，2GB 内存，XP）
	等设备进行了运行确认。

### IOS
	可在搭载 iOS 4.3 或更高版本的 iOS 设备上运行。

	但是，以下设备除外：
	- iPod touch 2nd Generation Late 2009
	- iPod touch 3rd Generation 8GB
	（不仅限于 Artemis，无法在这些设备上运行任何应用程序）

	此外，在 iPhone 3GS 和 iPod touch 3rd Generation 等非 Retina 模型上的运行，
	由于性能非常差，除非是专门针对低分辨率设计的应用程序。
	（支持这些设备是不切实际的）

	在御影的环境中，作为对低性能环境的检查，
	使用了
	- iPhone 4
	- iPad 1st Generation
	等设备进行了运行确认。

### Android
	可在搭载 Android 4.1 或更高版本的 Android 设备上运行。

	在御影的环境中，作为对低性能环境的检查，
	使用了
	- SO-04E
	等设备进行了运行确认。

### WebAssembly
	可在支持 WebAssembly 的浏览器中运行。

	在御影的环境中，主要是在以下环境中进行了运行确认：
	- Windows + Chrome / Firefox
	- macOS + Safari
	- Android + Chrome
	- iOS + Safari

## 开发环境

这是开发 Artemis Engine 应用程序所需的环境。

### Windows
	遵循功能环境。
	由于 Tools 文件夹中的各种工具是 Windows 专用的，
	因此开发原则上需要 Windows。

### iOS
	需要最新版的 Xcode 和能够运行的 macOS。

	即使不是最新版，也可以创建应用程序，
	但如果 Xcode 或 iOS SDK 较旧，则可能无法将应用程序上传到 App Store。

	为了在 iOS 设备上测试创建的应用程序，
	或者将其上传到 App Store，
	需要与苹果签订有偿的 iOS Developer Program 合约。
	（每年需要支付费用）

### Android
	可以在 Windows、Mac、Linux 上进行开发，
	但文档是以 Windows 为前提编写的。

	为了在 Google Play 上发布应用程序，
	需要 Google Play Developer 账户。
	（注册账户时需要支付一次注册费）

### WebAssembly
	虽然文档是以 Windows 为前提编写的，
	但只要理解了一定程度的原理，就可以在任何环境中进行开发。

    ※ 关于在 Mac 上的运行
	虽然 Artemis Engine 没有 Mac 版本，
	但是可以使用名为 Wine 的 Windows 兼容层来运行 Windows 版本。

	由于需要 Wine，因此不适用于最终用户，
	但如果您非常想在 Mac 上完成脚本开发，
	那么这是一个选择。
	（建议使用 bootcamp 或虚拟机）

