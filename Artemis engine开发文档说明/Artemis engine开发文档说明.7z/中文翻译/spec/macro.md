# 宏

宏是一种功能，它将现有的标签组合起来，创建新的标签。

例如，
+ 将角色A加载到图层中
+ 指定角色A在左侧、中间或右侧显示（图像文件为240×320）
+ 在屏幕上以淡入淡出的方式显示1秒钟

如果想要只需一行代码即可完成上述一系列步骤，比如
```
[chara_a pos="center"]
```

在这种情况下，只需在 macro.iet 文件中编写以下内容，就会创建 chara_a 标签。

```
*chara_a
[if estimate="$pos == 'left'"]
    [lyc id="1" file="chara_a"]
[/if]
[if estimate="$pos == 'center'"]
    [lyc id="3" file="chara_a"]
    [lyprop id="3" left="120"]
[/if]
[if estimate="$pos == 'right'"]
    [lyc id="2" file="chara_a"]
    [lyprop id="2" left="240"]
[/if]
[trans type="1" time="1000"]
[return]
```

宏的内容写在名为 macro.iet 的脚本文件中。
（如果使用其他文件，则使用 macroadd 标签）

标签的名称与定义新标签的标签相同。

标签的参数会自动展开为变量。

如果调用像这样的标签：

```
[new_tag param0="zero" param1="one"]
```

则会自动展开为变量并进行处理：

```
*new_tag
[print data="$param0"]	// 屏幕上显示 zero
[print data="$param1"]	// 屏幕上显示 one
[return]
```

您可以使用 var 标签 system="var_exist" 来检查是否传递了参数。

```
*new_tag
[var system="var_exist" name="t.result" target="param0" local="1"]
[if estimate="$t.result"]
    [print data="$param0"]
[else]
    [print data="param0 未传递"]
[/if]
```
