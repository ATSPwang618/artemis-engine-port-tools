# 启动设置文件 system.ini

Artemis Engine 在启动时首先读取启动设置文件。
在启动设置文件中，设置始终不变的项目。

```
[Section1]
Key1 = Value
Key2 = Value
Key3 = Value
...

[Section2]
Key1 = Value
Key2 = Value
Key3 = Value
...
```

这样写。


### 读取顺序
```
Windows
	将读取 WINDOWS 部分。

iOS
	首先，将读取 IOS 部分。

	然后，将读取 IOS:DeviceHorizontalResolutionXDeviceVerticalResolution 部分，
	并将 IOS 部分设置的每个项目进行“覆盖”。
	例如，在 iPhone 3G/3GS、iPod touch 1G/2G/3G 中，
	将读取 IOS:320X480 部分。
	这样做的目的是，在 IOS 部分中设置 iOS 版共享设置和
	未知设备的故障安全（防滑）设置，
	以及在不同分辨率的部分中设置已知设备的个别设置。

	最后，仅在 iOS 版本中，将读取 DeviceModelID 部分。
	此部分与 IOS 部分及
	IOS:DeviceHorizontalResolutionXDeviceVerticalResolution 部分不同，
	它会进行详细的图形缓存设置。
	通常情况下无需编辑此部分，
	但如果遇到似乎与图形缓存有关的问题，
	则可以通过编辑此部分来尝试改善。

Android
	将读取 ANDROID 部分。

WebAssembly
	将读取 WASM 部分。
```

### 平台共有

```
WIDTH、HEIGHT
	在脚本中的虚拟分辨率。
	这称为“舞台分辨率”。
	在 Windows 中，将创建指定大小的窗口。
	iOS 和 Android 中，与 Windows 的全屏幕相同，
	会自动进行缩放以适应整个屏幕。

SIDECUT
	当将舞台缩放到设备屏幕时，
	创建黑色区域以显示整个屏幕，
	或者裁剪上下或左右以确保不会有剩余的区域。
	指定 0 表示显示整个舞台。
	指定 1 表示根据需要将舞台的上下或左右部分裁剪到屏幕外。

SIDE_PICTURE
	当 SIDECUT 为 0 时，在黑色区域以平铺形式显示图像。
	指定图像文件的路径。

POWER_SAVING
	指定为 1 时，当屏幕无更新时会抑制绘制，
	以降低能耗。
	通常不使用。

BOOT
	最先加载的脚本文件的路径。

CHARSET
	设置脚本和已渲染字体文件的字符编码。
	默认为 Shift_JIS，如果想要使用 UTF-8，则设置为 UTF-8。
	如果设置为 UTF-8，则无法使用使用 Shift_JIS 编写的脚本和
	未使用 /utf8 选项生成的已渲染字体文件。
	另外，如果文件名中使用了多字节字符，则必须以 UTF-8 模式生成打包文件。
	请注意，UTF-16 中使用代理对的代码区段字符是无效的。

NO_SAVE
	指定为 1 时，不会创建存档文件。
	通常不使用。
```

### Windows

```
FRAMELESS
	指定为 1 时，创建无边框窗口。

RESIZABLE
	指定为 1 时，创建可调整大小的窗口。
	在无法使用硬件渲染的环境中，将强制禁用此选项。

FIXED_ASPECT_RATIO
	指定为 1 时，在 RESIZABLE 为 1 时，固定调整窗口大小时的宽高比。

FORCE_SOFTWARE_RENDER
	指定为 1 时，强制使用软件渲染。
	极少数情况下，即使可以使用硬件渲染，
	也可能出现画面异常的情况。
	在这种情况下，将此项目设置为 1，
	可能可以改善画面异常。
	此外，通过在启动 Artemis.exe 时添加 /fsr 参数，
	也可以实现相同的效果。

PREVENT_MULTIPLE_PROCESS
	如果要防止多重启动，则指定特定于应用程序的字符串。
	如果缺省或指定为空字符串，则不会防止多重启动。
	由于与其他应用程序重复会导致无法启动，因此建议使用具有唯一性保证的字符串，
	例如 GUID。
	可以使用不超过 260 个字符的除 \ 以外的任何字符。

SAVEPATH
	存档数据的文件夹路径。

SAVEPATH_CSIDL
	在 Windows 中，指定特殊文件夹的 CSIDL 值，
	可以设置保存数据的基准路径为 exe 所在文件夹以外的其他位置。

	例如，在 Windows 7 中，如果用户帐户为 hoge，
	且 SAVEPATH = foo\bar 和 SAVEPATH_CSIDL = 26，
	则通常 C:\Users\hoge\AppData\Roaming\foo\bar
	将成为保存数据的存储位置。

    CSIDL 必须以十进制数指定。
    有关 CSIDL 的详细信息，请参阅以下网站：

    http://msdn.microsoft.com/en-us/library/windows/desktop/bb762494%28v=vs.85%29.aspx
    这是 Microsoft 的官方信息。请在其他网站查找数字。

    http://chokuto.ifdef.jp/urawaza/prm/CSIDL.html
    有表格。

    http://ht-deko.minim.ne.jp/tech005.html
    在页面中部有表格。
```

### iOS

```
SURFACE_CACHE_SIZE
	指定在 VRAM 中保留的图像缓存的大小，以字节为单位。
	通常不需要设置。

FONT_CACHE_SIZE
	指定在 VRAM 中保留的字体缓存的大小，以字节为单位。
	通常不需要设置。
```

### WebAssembly

```
SAVEPATH
	WebAssembly 版本将保存数据存储在浏览器的 Indexed DB 中，
	这由域名管理。
	因此，如果在同一域名下设置多个游戏，则需要在此键中为每个游戏指定唯一的字符串。
	只能使用小写字母、数字和下划线(_)。

ASYNCIFY_URL
	仅用于 Asyncify 版本。
	有关详细信息，请参阅 webassembly 文件夹中的 readme.txt。

ASYNCIFY_HASH_LIST_URL
	仅用于 Asyncify 版本。
	有关详细信息，请参阅 webassembly 文件夹中的 readme.txt。
```