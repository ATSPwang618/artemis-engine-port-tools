# 系统变量

系统变量是由引擎自动创建的变量。

系统变量可以大致分为两种类型：
+ 从脚本中写入时具有意义的变量 （可写变量）
+ 从脚本中读取时具有意义的变量 （只读变量）

虽然只读系统变量也可以被写入，但一旦写入，之后就无法获取期望的值。


## 可写变量

### s.bgmvol
将BGM的音量设置为0（最小）到1000（最大）。
更改此变量可调整BGM的音量。

### s.sevol
将SE的主音量设置为0（最小）到1000（最大）。
更改此变量可调整所有SE的音量。

### s.segain.*
将具有指定ID的SE的音量设置为0（最小）到1000（最大）。
将*替换为ID。
更改此变量可按ID调整SE的音量。

### s.videovol
将全屏视频的音量设置为0（最小）到1000（最大）。
更改此变量可调整全屏视频的音量。
仅适用于Windows和Android。

### s.automodewait
以毫秒为单位设置自动模式的等待时间。
更改此变量可调整自动模式下的等待时间。

### s.backlog.annotation
在保存用于检索的信息时，此变量的值将作为注释参数添加。
还请参阅var标签system="get_backlog_tags"。

### s.http.cancel
请参阅httpget标签。


## 只读变量

### s.engineversion
运行中的Artemis引擎的版本。

### s.minimumsupportversion
保留了向后兼容性，但将来不应使用。

### s.savedataversion
保存数据格式的版本。
如果相差100，则根本无法加载。

### s.builddate
运行中的Artemis引擎构建的日期和时间。

### s.copyright
用于传递给对话框标签的版权声明字符串。

### s.datapath
游戏数据文件夹的绝对路径。

### s.savepath
存档数据文件夹的绝对路径。

### s.lp64
如果运行的二进制文件是使用LP64数据模型架构构建的，则为1，否则为0。

### s.windowsversion
运行中Windows的内部版本。
5=2000, 5.1=XP, 6=Vista, 6.1=7, 6.2=8, 6.3=8.1
如果在Windows 10上以兼容模式运行，则返回6.2。

仅适用于Windows。

### s.windowstouch
如果运行的PC支持Windows触摸，则包含1，否则包含0。

仅适用于Windows。

### s.iphonemodel
运行中的iOS设备的型号标识符（例如iPhone7,2）。
请参阅以下网站以获取列表：
http://ios.e-lite.org/

仅适用于iOS。

### s.iphoneversion
运行中的iOS版本。

仅适用于iOS。

### s.iphonelanguage
运行中的iOS语言设置（例如ja）。

仅适用于iOS。

### s.androidmodel
运行中的Android设备型号名称。

仅适用于Android。

### s.androidversion
运行中的Android版本。

仅适用于Android。

### s.versioncode
设置在运行APK中的版本代码。

仅适用于Android。

### s.versionname
设置在运行APK中的版本名称。
仅适用于Android。

### s.current_message_layer
当前选定的消息层的名称。

### s.status.automode
如果在自动模式下，则为1，否则为0。

### s.status.commandskip
如果在命令跳过模式下，则为1，否则为0。

### s.status.controlskip
如果在强制跳过模式下，则为1，否则为0。

### s.status.alreadyread
如果当前正在执行的脚本已阅读，则为1，否则为0。

### s.status.avoid
如果在紧急回避模式下，则为1，否则为0。

### s.status.windowbutton
请参阅setonwindowbutton标签。

### s.status.screendirection
当前屏幕方向：
+ 0 竖屏（主页按钮在底部）
+ 1 横屏（主页按钮在右侧）
+ 2 竖屏（主页按钮在顶部）
+ 3 横屏（主页按钮在左侧）

仅适用于iOS。

### s.status.screendirectionprevious
上一个屏幕方向。
值的含义与s.status.screendirection相同。

仅适用于iOS。

### s.status.statusbar
如果状态栏正在显示，则为1，否则为0。

仅适用于iOS和Android。

### s.wasm_sync_status
用于文件标签command="wasm_sync"的WASM SYNC的执行状态：
+ 0 执行完成
+ 1 在内部使用
+ 2 在内部使用
+ 3 下载列表中
+ 4 下载列表失败
+ 5 下载文件组中
+ 6 下载文件组失败

预期在WASM SYNC执行过程中在Lua onEnterFrame中引用。

仅适用于WebAssembly。

### s.wasm_sync_total
需要通过文件标签command="wasm_sync"下载的文件数量。
预期在WASM SYNC执行过程中在Lua onEnterFrame中引用。

仅适用于WebAssembly。

#### s.wasm_sync_current
通过文件标签command="wasm_sync"下载完成的文件数量。
预期在WASM SYNC执行过程中在Lua onEnterFrame中引用。

仅适用于WebAssembly。


## 只读但在脚本中需要初始化

### s.clickskip
如果等待，过渡或全屏视频（仅限Windows）可以通过点击跳过，则为1。

不会自动恢复为0，因此如果使用此系统变量，

则需要在每次脚本中初始化。

### s.overflowed
如果剧文从消息层溢出，则为1。

不会自动恢复为0，因此如果使用此系统变量，

则需要在每次脚本中初始化。
