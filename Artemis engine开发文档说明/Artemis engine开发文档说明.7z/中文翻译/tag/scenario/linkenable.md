# linkenable

使用link标签设置，并且通过linkdisable标签暂时禁用的链接，
将重新启用。
