# font

用于设置当前消息层的字体设置。

```
left
    NUMBER
        第一个字符的左边位置（对于竖排来说是右边位置）
    缺省
        继承之前的设置
top
    NUMBER
        第一个字符的顶部位置
    缺省
        继承之前的设置
width
    NUMBER
        一行的宽度
        如果超出此大小，将自动换行
    缺省
        继承之前的设置
height
    NUMBER
        一页的高度
        如果超出此大小，将自动插入点击等待并换页
    缺省
        继承之前的设置
face
    STRING
        指定字体名称
        首先将其视为TrueType/OpenType字体文件的路径来搜索文件
        如果找不到，则视为渲染后字体的基本名称来搜索文件
        如果仍然找不到，则在Windows和iOS中将其视为内置字体的名称来搜索
        如果在iOS、Android和WebAssembly中仍然找不到，则文字将不再显示
        在Windows中将自动回退到 "ＭＳ ゴシック"
    缺省
        继承之前的设置
rubyface
    STRING
        指定注音字体的名称
        规则与face参数相同
    缺省
        继承之前的设置
size
    NUMBER
        以像素为单位指定字号
        注意这不是指点数
    缺省
        继承之前的设置
shadow
    NUMBER
        指定文字的阴影距离（以像素为单位）
    缺省
        继承之前的设置
outline
    NUMBER
        指定文字的轮廓（描边）大小（以像素为单位）
    缺省
        继承之前的设置
rubysize
    NUMBER
        以像素为单位指定注音字的大小
        注意这不是指点数
    缺省
        继承之前的设置
rubyshadow
    NUMBER
        指定注音字的阴影距离（以像素为单位）
    缺省
        继承之前的设置
rubyoutline
    NUMBER
        指定注音字的轮廓（描边）大小（以像素为单位）
    缺省
        继承之前的设置
spacetop
    NUMBER
        行顶部和注音之间的间隔大小
        可以是负值
    缺省
        继承之前的设置
spacemiddle
    NUMBER
        注音和正文之间的间隔大小
        可以是负值
    缺省
        继承之前的设置
spacebottom
    NUMBER
        行底部和正文之间的间隔大小
        可以是负值
    缺省
        继承之前的设置
kerning
    NUMBER
        字距大小
        可以是负值
    缺省
        继承之前的设置
rubykerning
    NUMBER
        注音字的字距大小
        可以是负值
    缺省
        继承之前的设置
align
    left
        左对齐
    center
        居中对齐
    right
        右对齐
    equalize
        自动调整字符间距以填满整行
    缺省
        继承之前的设置
style
    ; 以逗号分隔指定
    bold
        加粗
        仅当使用Windows内置字体时有效
        在其他平台上指定会导致文字不显示
    italic
        斜体
        仅当使用Windows内置字体时有效
        在其他平台上指定会导致文字不显示
    underline
        下划线
    strikeout
        删除线
    缺省
        继承之前的设置
vertical
    0
        横排模式
    1
        竖排模式
        非Windows平台需要有专门为竖排生成的渲染后字体
        在Windows上需要使用专门为竖排生成的渲染后字体，或者使用以 "@" 开头的内置竖排字体
    缺省
        继承之前的设置
hung
    0
        禁止禁止符处理时的悬挂处理
        也在点击等待图标溢出时将其放置在下一行行首
    1
        在禁止符处理时进行悬挂处理
        即使点击等待图标溢出也会被放置在溢出的位置
    缺省
        继承之前的设置
color
    RRGGBB
        文字颜色
    缺省
        继承之前的设置
shadowcolor
    RRGGBB
        文字阴影的颜色
    缺省
        继承之前的设置
outlinecolor
    RRGGBB
        文字轮廓（描边）的颜色
    缺省
        继承之前的设置
alpha
    0...255
        每个文字的不透明度
    缺省
        继承之前的设置
xscale
    NUMBER
        每个文字的水平缩放比例（百分比）
        锚点固定在文字中心
    缺省
        继承之前的设置
yscale
    NUMBER
        每个文字的垂直缩放比例（百分比）
        锚点固定在文字中心
    缺省
        继承之前的设置
rotate
    0...359
        每个文字的旋转角度
        锚点固定在文字中心
    缺省
        继承之前的设置
layermode
    ; lyc标签的layermode参数相同
entirealpha
    0...255
        整个页面的不透明度
    缺省
        继承之前的设置
entirexscale
    NUMBER
        整个页面的水平缩放比例（百分比）
    缺省
        继承之前的设置
entireyscale
    NUMBER
        整个页面的垂直缩放比例（百分比）
    缺省
        继承之前的设置
entirerotate
    0...359
        整个页面的旋转角度
    缺省
        继承之前的设置
entireanchorx
    NUMBER
        整个页面的锚点的X坐标
        缩放和旋转以此坐标为中心进行
    缺省
        继承之前的设置
entireanchory
    NUMBER
        整个页面的锚点的Y坐标
        缩放和旋转以此坐标为中心进行
    缺省
        继承之前的设置
anchorcenter
    0
        使用entireanchorx和entireanchory参数的指定
    1
        忽略entireanchorx和entireanchory参数的指定
        并将锚点固定在页面中心
    缺省
        继承之前的设置
stack
    0
        不将先前的设置存储在字体堆栈中
        如果没有要回退的/font标签，则强烈建议指定此项
        （这对于防止保存文件变得过大非常重要）
    缺省, 1
        将先前的设置存储在字体堆栈中
        通过/font标签调用，可以回退到最后一次存储在字体堆栈中的设置
        字体堆栈可以存储任意数量的设置，因此可以使用font标签的次数，以及使用/font标签按顺序回退设置
overflow
    缺省, 0
        当情节文本超出width和height参数指定的范围时，自动插入点击等待和换页
    1
        当情节文本超出width和height参数指定的范围时，不执行任何操作
```

默认字体设置如下。
```
[font
	left          = 0
	top           = 0
	width         = 640
	height        = 480
	face          = "ＭＳ ゴシック" // 适用于 iOS 的“HiraKakuProN-W3”，适用于 Android 的请参见下文
	rubyface      = "ＭＳ ゴシック" // 适用于 iOS 的“HiraKakuProN-W3”，适用于 Android 的请参见下文
	size          = 24
	shadow        = 0
	outline       = 0
	rubysize      = 8
	rubyshadow    = 0
	rubyoutline   = 0
	spacetop      = 0
	spacemiddle   = 0
	spacebottom   = 0
	kerning       = 0
	rubykerning   = 0
	align         = left
	style         = ""
	vertical      = 0
	hung          = 1
	color         = FFFFFF
	shadowcolor   = 000000
	outlinecolor  = 000000
	alpha         = 255
	xscale        = 100
	yscale        = 100
	rotate        = 0
	layermode     = normal
	entirealpha   = 255
	entirexscale  = 100
	entireyscale  = 100
	entirerotate  = 0
	entireanchorx = 0
	entireanchory = 0
	anchorcenter  = 1
	overflow      = 0
]
```

在Android上，默认情况下，face参数使用以下顺序的存在字体。

```
/system/fonts/MTLmr3m.ttf
/system/fonts/MTLc3m.ttf
/system/fonts/RyoGothicPlusN-Medium.otf
/system/fonts/DroidSansFallback.ttf
```