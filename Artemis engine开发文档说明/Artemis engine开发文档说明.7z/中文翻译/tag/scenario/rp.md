# rp

将场景文本分页。

```
backlog
	0
		不将分页前的场景文本存入后台日志
		忽略writebacklog标签的设置
	1
		将分页前的场景文本存入后台日志
		忽略writebacklog标签的设置
	缺省
		按照writebacklog标签的设置进行处理
```