# link

设置在剧情文本中创建链接。

当剧情文本被link标签和/link标签包围时，
点击后会将执行位置移动到指定位置。

可以用于简单的选项等。

```
file
	; jump标签的file参数相同
label
	; jump标签的label参数相同
type
	; 指定强调显示的类型
	缺省, 0
		添加一个白色的方形板，通过加法合成进行渐变叠加
	1
		更改文字颜色
color
	RRGGBB
		当type参数为1时，强调显示时的文字颜色
	缺省
		默认为0x000000
shadowcolor
	RRGGBB
		当type参数为1时，强调显示时的文字阴影颜色
	缺省
		默认为0x000000
outlinecolor
	RRGGBB
		当type参数为1时，强调显示时的文字轮廓颜色
	缺省
		默认为0x000000
```