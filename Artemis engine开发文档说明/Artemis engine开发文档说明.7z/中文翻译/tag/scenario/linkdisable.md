# linkdisable

将使用link标签设置的链接暂时禁用。
