# writebacklog

设置是否将场景文本存入历史。

```
mode
	缺省, 0
		不存入
	1
		存入
```