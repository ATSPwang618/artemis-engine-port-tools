# scetween

设置场景文本的动画效果。

```
mode
	init
		删除指定类型的动画设置，指定的type参数之外的所有参数将被忽略
	add
		添加指定类型的动画设置，除了type参数之外的所有参数都将被忽略
type
	in
		出现
	out
		退场
	show
		通过scein出现
	hide
		通过sceout退场
	backlog_down_in
		向过去的后台中逐页出现
	backlog_down_out
		向过去的后台中逐页退场
	backlog_up_in
		向现在的后台中逐页出现
	backlog_up_out
		向现在的后台中逐页退场
param
	STRING
		left,top,alpha,xscale,yscale,rotate,entireleft,entiretop,
		entirealpha,entirexscale,entireyscale,entirerotate
		以上任何字体属性名
		left,top代表每个字符的位置，
		entireleft,top代表整个页面的位置
		其他属性的含义请参考font标签
ease
	; 与lytween标签的ease参数相同
diff
	NUMBER
		指定param中属性的原始值与动画前后值之间的差值
delay
	NUMBER
		指定动画每个字符开始的等待时间，单位为毫秒
		可以使用此参数调整场景的显示速度
time
	NUMBER
		指定动画持续时间，单位为毫秒
randomdelay
	缺省, 0
		从页面开头的字符开始依次延迟
	1
		使延迟的字符不按顺序而是随机显示
		页面内的字符将从随机位置开始显示
```