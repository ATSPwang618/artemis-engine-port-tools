# fontdefault

定义字体的默认设置。

除了没有stack参数外，其他参数与font标签相同。

请参考font标签。