# scein

将使用sceout隐藏的场景文本还原显示。
