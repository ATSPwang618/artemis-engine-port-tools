# fontinit

将当前消息层的字体设置更改为由fontdefault标签设置的默认设置。

字体堆栈将被初始化。