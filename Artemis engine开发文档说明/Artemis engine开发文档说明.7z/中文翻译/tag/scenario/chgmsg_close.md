# /chgmsg

将当前消息层回退到消息层堆栈中存储的最后一个消息层。

请参考chgmsg标签的stack参数。
