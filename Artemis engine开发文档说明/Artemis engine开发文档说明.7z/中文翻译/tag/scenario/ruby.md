# ruby

在ruby标签和/ruby标签中间的文本上添加注音。

```
text
	STRING
		注音的内容字符串
```

使用方式如下。
```
[ruby text="カピバラ"]鬼天竺鼠[/ruby]
```

带有注音的文本中间不会自动换行。
