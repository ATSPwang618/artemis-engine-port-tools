# automode

设置自动模式。

```
allow
	0
		禁用自动模式
	1
		启用自动模式
layer
	STRING
		自动模式下自动显示的图层的图层ID
		在此处指定的图层将与自动模式同步，visible将自动变化
	缺省
		禁用自动显示
stopbyclick
	0
		不通过左键单击停止自动模式
	1
		通过左键单击停止自动模式
		默认设置
	缺省
		保留之前的设置
stopbystop
	0
		不通过 stop 标签停止自动模式
	1
		通过 stop 标签停止自动模式
		默认设置
	缺省
		保留之前的设置
syncse
	STRING ARRAY
		指定SE ID，直到指定的SE播放结束才继续
		可以指定多个
	缺省
		保留之前的设置
```

自动模式的等待时间可以通过系统变量 `s.automodewait` 指定。

