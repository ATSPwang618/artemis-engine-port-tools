# savess

将由takess拍摄的屏幕截图保存为PNG文件。

```
file
	PATH
		保存位置的文件名
width
	NUMBER
		重新调整的宽度
	缺省
		不重新调整大小
height
	NUMBER
		重新调整的高度
	缺省
		不重新调整大小
```