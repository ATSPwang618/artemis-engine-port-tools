# tweenset

将多个lytween标签用tweenset标签和/tweenset标签包围起来，以便按顺序执行这些动画。
这被称为Tween集。

如果删除与Tween集内的Tween相关联的图层，或者通过lytweendel标签完成Tween本身，则Tween集内的所有其他Tween也将被删除。

使用如下：

// 顺时针移动图层...
[tweenset]
	[lytween id=1 param=left from=0 to=100 time=1000]
	[lytween id=1 param=top  from=0 to=100 time=1000]
	[lytween id=1 param=left from=100 to=0 time=1000]
	[lytween id=1 param=top  from=100 to=0 time=1000]
[/tweenset]
