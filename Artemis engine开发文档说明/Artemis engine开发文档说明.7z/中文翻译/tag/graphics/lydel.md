# lydel

删除图层

```
id
	STRING
		要删除的图层ID
```