# takess

拍摄屏幕截图。
拍摄结果将由savess标签保存。

在WebAssembly版本中，执行此标签时并未进行拍摄，而是在下一次绘制时进行拍摄。

从脚本执行状态转换为绘制状态的时刻是在执行stop、@、wait、lytween sync="1"、trans等标签后。

因此，在WebAssembly版本中，如果在takess之后立即执行上述标签而不是savess，将导致保存失败。
