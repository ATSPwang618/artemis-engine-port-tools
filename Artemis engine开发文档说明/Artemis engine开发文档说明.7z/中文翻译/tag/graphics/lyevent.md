# lyevent

设置图层的事件处理程序。

```
id
	STRING
		目标图层的ID
		无法指定图层集
type
	click
		点击
	rollover
		悬停
	rollout
		滚出
	dragin
		拖动开始
	drag
		拖动中，在每帧执行
	dragout
		拖动结束
mode
	init
		分配事件处理程序
	reset
		取消事件处理程序
	enable
		重新启用已暂时禁用的事件处理程序
	disable
		保持事件处理程序信息，临时禁用事件处理程序的执行
file
	; 与jump标签 file参数相同
label
	; 与jump标签 label参数相同
call
	缺省, 0
		不将脚本执行位置存储在调用堆栈中
		与jump标签相同
	1
		将脚本执行位置存储在调用堆栈中
		与call标签相同
		通常应指定此项，并在事件处理程序中使用return返回
handler
	STRING
		在更改执行位置到file、label参数指示的位置之前，执行任意标签作为事件处理程序
		在此参数中指定要执行的标签名称
		由于标签的参数会引用lyevent标签指定的所有参数，因此请随时添加lyevent标签本身及handler参数中指定的标签所需的参数
	缺省
		不执行任何操作
penetration
	缺省, 0
		对于点击和悬停事件，如果图层重叠，则下方图层不会执行事件处理程序
	1
		对于点击和悬停事件，即使图层重叠，也会执行下方图层的事件处理程序
		事件执行顺序从下到上，而不是从上到下，请注意
```

file、label、handler三个参数中至少有一个是必需的。

handler参数可用于，例如，将相同的事件处理程序分配给多个图层，并根据事件来源进行处理，如下所示。

```
[lyevent id=1 mode=init type=click label=event_handler handler=var name=clicked_button data=1]
[lyevent id=2 mode=init type=click label=event_handler handler=var name=clicked_button data=2]
[lyevent id=3 mode=init type=click label=event_handler handler=var name=clicked_button data=3]
*event_handler
```

点击的按钮是 `[print data=$clicked_button]`。
