# flip

它与 trans type="0" 的效果几乎相同，但不会退出脚本执行循环。

trans标签在执行时立即反映在屏幕上，
而flip标签则在下一次屏幕绘制（如trans、wait、stop等）时才反映在屏幕上。