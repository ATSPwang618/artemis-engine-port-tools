# lyedit

对图层中加载的图像进行加工。

在iOS上，使用lyc标签加载图像时，如果将economize参数设置为1，则无法对图层进行加工。

```
id
	STRING
		要操作的图层的ID
		不能指定图层集合
mode
	negative
		执行负片转换
	gray
		转换为灰度图
	sepia
		执行棕褐色效果
	add
		执行颜色加法，使用color参数指定颜色
	multiply
		执行颜色乘法，使用color参数指定颜色
	blend
		对指定的图像文件执行Alpha合成
color
	RRGGBB
		当mode参数为add或multiply时使用的颜色
file
	PATH
		当mode参数为blend时使用的用于合成的图像文件的路径
left
	NUMBER
		当mode参数为blend时，合成目标左侧位置
top
	NUMBER
		当mode参数为blend时，合成目标顶部位置
```

由于图像处理是在CPU而不是GPU上进行的，因此这是一项非常耗费资源的操作。
因此，强烈建议仅在必要时使用，并进行充分的性能评估。

在iOS上，blend模式参数的规格限制为，
如果在使用lyc标签加载图像时，file参数指定的图像文件已经关联到另一个图层，
并且在使用lyc标签加载图像时将economize参数设置为1，则无法将其用作覆盖源图像。
