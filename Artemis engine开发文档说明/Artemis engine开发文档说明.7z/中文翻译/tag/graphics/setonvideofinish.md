# setonvideofinish

设置视频图层播放完成事件处理程序。

```
id
	STRING
		目标图层的ID
file
	; lyevent标签的file参数相同
label
	; lyevent标签的label参数相同
call
	; lyevent标签的call参数相同
handler
	; lyevent标签的handler参数相同
```