# setondragout

保留是为了向后兼容

请不要在将来使用它
