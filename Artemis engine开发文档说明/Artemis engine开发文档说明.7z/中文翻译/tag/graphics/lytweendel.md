# lytweendel

强制完成由lytween标签设置的缓动。

```
id
	; 与lyprop标签的id参数相同
```