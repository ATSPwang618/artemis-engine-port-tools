# lytween

设置图层属性连续变化的“缓动”效果。
用于实现简单动画，例如滑动或淡入淡出，通过改变属性值来实现。

```
id
	; 与lyprop标签的id参数相同
param
	left
		缓动左边位置
	top
		缓动顶部位置
	alpha
		缓动不透明度
	xscale
		缓动水平缩放率
	yscale
		缓动垂直缩放率
	rotate
		缓动旋转角度
from
	NUMBER
		起始值
to
	NUMBER
		结束值
ease
	; 设置“缓动方法”，为值的变化增加缓动效果
	; 每种效果可以通过实际移动或参考以下网站等来了解
	; http://easings.net/ja
	easein_quad
	easeout_quad
	easeinout_quad
	easein_cubic
	easeout_cubic
	easeinout_cubic
	easein_quart
	easeout_quart
	easeinout_quart
	easein_quint
	easeout_quint
	easeinout_quint
	easein_expo
	easeout_expo
	easeinout_expo
	easein_circ
	easeout_circ
	easeinout_circ
	easein_sine
	easeout_sine
	easeinout_sine
	easein_back
	easeout_back
	easeinout_back
	easein_elastic
	easeout_elastic
	easeinout_elastic
	easein_bounce
	easeout_bounce
	easeinout_bounce
	缺省
		不使用缓动方法
		值直线变化
time
	NUMBER
		缓动所需时间，以毫秒为单位
delay
	NUMBER
		开始缓动之前的延迟时间，以毫秒为单位
	缺省
		立即开始缓动
loop
	-1
		无限循环
	缺省, 0
		仅执行一次
	NUMBER
		指定次数循环
yoyo
	-1
		无限循环
		循环时，交换from和to值
	缺省, 0
		仅执行一次
	NUMBER
		指定次数循环
		循环时，交换from和to值
loopdelay
	缺省
		不等待缓动重复
	NUMBER
		以毫秒为单位，指定缓动重复时的延迟时间
sync
	; 不可与delete、file、label、handler参数同时使用
	缺省, 0
		不等待缓动完成
	1
		等待缓动完成
delete
	; 不可与sync、file、label、handler参数同时使用
	缺省, 0
		缓动完成后不删除图层
	1
		缓动完成后删除图层
		用于在图层滑出屏幕时删除图层等情况
file
	; 缓动完成后执行事件处理程序
	; 不可与sync、file、label、handler参数同时使用
	; 与lyevent标签的file参数相同
label
	; 缓动完成后执行事件处理程序
	; 不可与sync、file、label、handler参数同时使用
	; 与lyevent标签的label参数相同
handler
	; 缓动完成后执行事件处理程序
	; 不可与sync、file、label、handler参数同时使用
	; 与lyevent标签的handler参数相同
```