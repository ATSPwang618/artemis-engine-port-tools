# delonvideofinish

释放使用 setonvideofinish 设置的事件处理程序。

```
id
	STRING
		待取消的图层ID
```