# lyrename

更改图层的ID。

```
id
	STRING
		目标图层的ID
to
	STRING
		更改后的ID
```

用于进行不伴随重新加载的图层树的重组。
