# anime

简单地将多个图像文件连续显示在一起，加载到图层中以创建简单的动画。

```
- id
	STRING
		目标图层的ID
- mode
	init
		加载动画的第一帧
		需要file参数
	add
		加载动画的第二帧及以后的帧
		需要file参数和time参数
	end
		完成动画的加载
		需要time参数
- file
	PATH
		要加载的图像文件的路径
- mask
	PATH
		要作为蒙版图像加载的图像文件的路径
	缺省
		不使用蒙版图像
- time
	NUMBER
		指定显示此帧的时机，以毫秒为单位，从动画开始计时
- loop
	; 仅在mode参数为init时指定
	缺省, -1
		循环播放动画
	0
		仅播放一次动画
	NUMBER
		播放指定次数的动画
- left
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的left参数相同
- top
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的top参数相同
- alpha
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的alpha参数相同
- anchorx
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的anchorx参数相同
- anchory
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的anchory参数相同
- xscale
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的xscale参数相同
- yscale
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的yscale参数相同
- rotate
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的rotate参数相同
- reversex
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的reversex参数相同
- reversey
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的reversey参数相同
- clip
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的clip参数相同
- layermode
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的layermode参数相同
- negative
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的negative参数相同
- grayscale
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的grayscale参数相同
- colormultiply
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的colormultiply参数相同
- visible
	; 用于此帧的lyprop兼容属性
	; 与lyprop标签的visible参数相同
```

删除时，请使用lydel标签。

使用如下所示：
```
// 每秒30帧的动画
[var name=i data=0]
[loop estimate="$i < 30"]
	[if estimate="$i == 0"]
		// 第一帧必须使用 mode=init
		[anime id=90 mode=init file=blueglyph/glyph0]
	[/if]
	[if estimate="$i != 0"]
		// 之后的帧要使用 mode=add
		[anime id=90 mode=add file="$'blueglyph/glyph' + i" time="$i * 33"]
	[/if]
	[var name=i data="$i + 1"]
[/loop]
// 设置最后一帧的时间
[anime id=90 mode=end time="$i * 33"]
```