# lyc

将图像加载到图层中。

```
id
	STRING
		要加载图像的图层ID
file
	PATH
		图像文件的路径
		可以使用PNG格式和JPEG格式
		某些PSD格式也可以读取，但会作为合并的图像加载，并且不能保证所有PSD文件都可以读取
		缺省时
		生成单色图层模式
		需要width、height和color参数
mask
	PATH
		作为蒙版图像加载的图像文件的路径
		必须与file参数指定的图像文件大小相同
		缺省时
		不使用蒙版图像
width
	NUMBER
		当缺省file参数并设置为单色图层生成模式时，图层的宽度
		如果指定了file参数，则将被忽略
height
	NUMBER
		当缺省file参数并设置为单色图层生成模式时，图层的高度
		如果指定了file参数，则将被忽略
color
	RRGGBB, AARRGGBB
		当缺省file参数并设置为单色图层生成模式时，图层的填充颜色
		如果指定了file参数，则将被忽略
```