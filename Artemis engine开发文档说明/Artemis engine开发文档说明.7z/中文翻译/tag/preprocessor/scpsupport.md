# &scpsupport

设置脚本输入辅助功能。

```
mode
	init
		初始化脚本输入辅助功能
	add
		添加要执行脚本输入辅助的字符串
	addsp
		为了向后兼容而保留，但请不要使用。
char
	STRING
		当该参数指定的值出现在行尾时，将分配标签
	缺省
		分配标签给换行符
command
	STRING
		分配的标签
		不能包含括号 [ 或 ]，只能指定一个标签
```

当检测到脚本中紧随在场景文本后面的换行时，将自动执行指定的标签。

例如，如果脚本中的一行相当于游戏屏幕上的一页，可以通过以下方式设置：
```
  [&scpsupport mode="init"]
  [&scpsupport mode="add" command="@"]
  [&scpsupport mode="add" command="rp"]
```

在脚本的开头附近进行设置，那么原本需要写成
```
  シナリオです。@[rp]
  ２ページ目です。@[rp]
```
的部分，只需写成
```
  シナリオです。
  ２ページ目です。
  ```
即可实现等待点击和换页动作。

但是，如果换行符前不是场景文本，则不会应用该功能。

例如，如果换行符前是标签等，则不会进行等待点击和换页。

另外，通过使用 char 参数，可以实现以下效果：
```
  [&scpsupport mode="init"]
  [&scpsupport mode="add" command="@"]
  [&scpsupport mode="add" command="rp"]
  [&scpsupport mode="add" char="】" command="rt"]
```
通过这样的设置，可以将
```
  【スライム】[rt]
  「ぷるぷる」@[rp]
```
写成
```
  【スライム】
  「ぷるぷる」
```
