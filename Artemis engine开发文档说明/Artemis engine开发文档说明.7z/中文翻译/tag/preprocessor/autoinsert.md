# &autoinsert

为脚本上的空行、行头和行尾分配标签。

```
target
	blankline
		空行
	linehead
		行头
	lineend
		行尾
command
	STRING
		分配的标签
		可以包含括号 [ 或 ]，并且可以指定多个标签
	缺省
		取消分配
```

以下功能使脚本能够以简洁的方式实现。

```
////////////////////////////////////////////////////////////////
// 原始脚本

[seplay id="100" file="voice_0"]
【スライム】[rt]
「ぷるぷる」@[rp]

[rt]
スライムはぷるぷるしているようだ。@[rp]

[seplay id="100" file="voice_1"]
【スライム】[rt]
「ぷるぷるぷるぷる」@[rp]

[rt]
スライムは何かを準備している。@[rp]

[seplay id="100" file="voice_2"]
【スライム】[rt]
「メラ！」@[rp]

////////////////////////////////////////////////////////////////
// macro.iet

*onblankline
[rp]
[var name="scpstat" data="none"]
[return]

*onlinehead
[if estimate="$scpstat == 'none'"]
    // 直前が話者名表示でないので、一行空ける
    [rt]
[/if]
[return]

*onlineend
@[rt]
[return]

*スライム
[seplay id="100" file="$'voice_' + voice_num"]
[var name="voice_num" data="$voice_num + 1"]
[print data="【スライム】"][rt]
[var name="scpstat" data="talker"]
[return]


////////////////////////////////////////////////////////////////
// 简化后的脚本

[&autoinsert target="blankline" command="[onblankline]"]
[&autoinsert target="linehead"  command="[onlinehead]" ]
[&autoinsert target="lineend"   command="[onlineend]"  ]

[スライム]
「ぷるぷる」

スライムはぷるぷるしているようだ。

[スライム]
「ぷるぷるぷるぷる」

スライムは何かを準備している。

[スライム]
「メラ！」
```