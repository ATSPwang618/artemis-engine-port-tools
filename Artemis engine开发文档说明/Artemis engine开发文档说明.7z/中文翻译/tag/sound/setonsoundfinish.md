# setonsoundfinish

设置声音播放完成事件处理程序。

```
id
	STRING
		目标SE的ID
	缺省
		设置BGM的播放完成事件处理程序
file
	; lyevent标签的file参数相同
label
	; lyevent标签的label参数相同
call
	; lyevent标签的call参数相同
handler
	; lyevent标签的handler参数相同
```