# delonsoundfinish

解除使用setonsoundfinish设置的事件处理程序。

```
id
	STRING
		要解除的SE的ID
	缺省
		解除BGM的播放完成事件处理程序
```