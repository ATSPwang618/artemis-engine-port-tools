# sefade

更改SE的增益。

```
id
	; seplay标签的id参数相同
gain
	; sfade标签的gain参数相同
time
	; sfade标签的time参数相同
```