# span

更改BGM的声像。

```
pan
	; splay标签的pan参数相同
time
	NUMBER
		以毫秒为单位的淡入淡出时间
	缺省
		不进行淡入淡出
```