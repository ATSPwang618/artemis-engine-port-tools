# seplay

播放SE。

```
id
	STRING
		目标SE的ID
file
	; splay标签的file参数相同
loop
	1
		循环播放
	缺省, 0
		不循环播放
gain
	; splay标签的gain参数相同
pan
	; splay标签的pan参数相同
time
	; splay标签的time参数相同
buffer
	; splay标签的buffer参数相同
skippable
	缺省, 0
		在跳过时也播放SE
	1
		在跳过时不播放SE
```