# sxfade

交叉淡入BGM。

```
file
    ; splay标签的file参数相同
loop
    ; splay标签的loop参数相同
gain
    ; splay标签的gain参数相同
pan
    ; splay标签的pan参数相同
time
    NUMBER
        淡入时间（毫秒）
    缺省
        不进行淡入
buffer
    ; splay标签的buffer参数相同
```