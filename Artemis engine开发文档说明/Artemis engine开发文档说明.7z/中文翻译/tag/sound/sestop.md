# sestop

停止SE的播放。

```
id
	; seplay标签的id参数相同
time
	; sstop标签的time参数相同
```