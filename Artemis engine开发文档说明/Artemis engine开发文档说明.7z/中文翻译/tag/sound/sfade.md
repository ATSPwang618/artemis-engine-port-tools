# sfade

更改BGM的增益。

```
gain
	; splay标签的gain参数相同
time
	NUMBER
		以毫秒为单位的淡入淡出时间
	缺省
		不进行淡入淡出
```