# sstop

停止BGM。

```
time
	NUMBER
		淡出时间（毫秒）
	缺省
		不进行淡出
```