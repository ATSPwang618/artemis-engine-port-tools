# sepan

更改SE的声像。

```
id
	; seplay标签的id参数相同
pan
	; span标签的pan参数相同
time
	; span标签的time参数相同
```