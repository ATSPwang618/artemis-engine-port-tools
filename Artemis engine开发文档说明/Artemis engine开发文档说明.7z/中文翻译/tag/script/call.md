# call

将脚本的执行位置存储到调用栈中，然后进行更改。
也称为调用子例程。

```
file
	; 与jump标签的file参数相同
label
	; 与jump标签的label参数相同
```

在call目标处执行return标签，将返回到call的起始点。
