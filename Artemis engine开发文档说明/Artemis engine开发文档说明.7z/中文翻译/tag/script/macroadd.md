# macroadd

添加要用作宏定义的文件，默认情况下只有 macro.iet。

```
file
	PATH
		脚本文件的路径
```