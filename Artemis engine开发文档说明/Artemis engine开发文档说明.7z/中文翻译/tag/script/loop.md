# loop

执行循环操作。

```
estimate
	0
		跳过/loop之间的脚本
	NUMBER
		不跳过脚本
```

例：
```
[var name="i" data="0"]
[loop estimate="$i < 100"]
	这是第 [print data="$i"] 次循环。@[rp]
	[var name="i" data="$i + 1"]
[/loop]
```