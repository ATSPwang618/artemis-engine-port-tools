# if

执行条件分支。

```
estimate
	0
		跳过elseif、else、/if之间的脚本
	NUMBER
		不跳过脚本
```

例：
```
[var name="i" data="3"]
[if estimate="$i == 3"]
	变量 i 等于 3。@[rp]
[elseif estimate="$i == 4"]
	变量 i 等于 4。@[rp]
[else]
	变量 i 既不等于 3 也不等于 4。@[rp]
[/if]
```