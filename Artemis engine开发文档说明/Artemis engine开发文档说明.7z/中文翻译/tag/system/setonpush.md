# setonpush

设置按键输入事件处理程序。

```
key
	NUMBER
		分配的键的键ID
		请参阅 spec/key_id.xls 获取键ID
keyrepeat
	默认，0
		不重复按键
	1
		重复按键
		仅适用于Windows
file
	; lyevent 标签的 file 参数相同
label
	; lyevent 标签的 label 参数相同
call
	; lyevent 标签的 call 参数相同
handler
	; lyevent 标签的 handler 参数相同
```

在Windows版本中，将 keyrepeat 参数设置为 1 会导致在按下键时立即调用事件处理程序，然后在经过0.5秒后，直到释放键为止，每帧都会调用事件处理程序。

重复触发之间的时间间隔无法更改。

如果想要调整重复触发的间隔，请在Lua脚本中使用 e:now()，如果事件处理程序在上次调用后未经过0.1秒，则不执行任何操作。
