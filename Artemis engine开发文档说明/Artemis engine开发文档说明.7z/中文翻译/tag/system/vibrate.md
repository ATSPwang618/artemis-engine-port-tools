# vibrate

触发设备的振动。
仅适用于iOS和Android。