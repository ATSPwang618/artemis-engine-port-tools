# delonhidein

取消使用 setonhidein 设置的事件处理程序。