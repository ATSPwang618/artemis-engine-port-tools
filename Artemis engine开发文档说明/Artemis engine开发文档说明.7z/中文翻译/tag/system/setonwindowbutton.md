# setonwindowbutton

设置窗口按钮按下事件处理程序。
仅适用于Windows。

```
button
	0
		关闭按钮（×按钮）
	1
		最大化按钮
	2
		最小化按钮
	默认
		由于已弃用，因此不建议使用
file
	; lyevent 标签的 file 参数相同
label
	; lyevent 标签的 label 参数相同
call
	; lyevent 标签的 call 参数相同
handler
	; lyevent 标签的 handler 参数相同
```

以下内容已弃用。

当调用事件处理程序时，系统变量 `s.status.windowbutton` 将设置如下：

```
0
	关闭按钮（×按钮）
1
	最大化按钮
2
	最小化按钮
```