# statusbar

切换状态栏的显示/隐藏。
仅适用于iOS和Android。

```
visible
	0
		隐藏
	1
		显示
```