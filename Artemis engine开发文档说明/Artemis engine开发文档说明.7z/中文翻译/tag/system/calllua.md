# calllua

执行 Lua 函数。
请参阅 lua 标记。

```
function
	STRING
		要执行的函数名。
```

由于所有参数都作为 Lua 表传递给函数，
因此可以将信息作为参数传递给 Lua 函数。

另外，从引擎调用的所有 Lua 函数都将接收一个名为 engine 的第一个参数。
按照惯例，该参数通常被命名为 e。

有关 engine 对象中实现的函数，请参阅 Lua 函数参考文档。

```
[lua]
function myFunction(e)
	e:debug("Hello, Artemis Lua World!")
end
[/lua]
[calllua function="myFunction"]
```