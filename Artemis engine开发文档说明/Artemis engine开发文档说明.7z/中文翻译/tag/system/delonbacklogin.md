# delonbacklogin

取消使用 setonbacklogin 设置的事件处理程序。
