# callnative

执行非 Artemis 脚本或 Lua 脚本的原生代码。

+ 在 Windows 上，您可以调用任意 DLL 中的函数，
+ 在 iOS 上，您可以调用任意 Objective-C 中的类方法，
+ 在 Android 上，您可以调用任意 Java 中的静态方法，
+ 在 WebAssembly 上，您可以调用 JavaScript 本身。

### Windows

```
result
	STRING
		存储调用的原生代码返回的字符串的变量名称
module
	PATH
		DLL 文件的路径
method
	STRING
		函数名
param
	STRING
		要传递给函数的字符串
```


实现 DLL 中的函数的定义如下所示。
```
extern "C" __declspec(dllexport) char* 任意的函数名(const char*)
extern "C" __declspec(dllexport) void Delete(const char*)
```
请在 Delete 函数中实现释放由 "任意的函数名" 返回的字符串缓冲区的逻辑。


### iOS
```
result
	STRING
		存储调用的原生代码返回的字符串的变量名称
module
	STRING
		类名
method
	STRING
		包含冒号的选择器名
param
	STRING
		要传递给函数的字符串
```

实现类方法的定义如下所示。
```
+(NSString)任意的选择器名:(NSString)
```

### Android
```
result
	STRING
		存储调用的原生代码返回的字符串的变量名称
module
	STRING
		JNI 表示的完整类名
		如果要指定包含在包 com.ies_net.artemis 中的类 Test，则应为 com/ies_net/artemis/Test
method
	STRING
		方法名
param
	STRING
		要传递给函数的字符串
```

实现静态方法的定义如下所示。
```
public static String 任意的方法名(NativeActivity, String)
```

### WebAssembly
```
result
	STRING
		eval 的返回值
method
	STRING
		JavaScript 代码
		将直接传递给 eval
```