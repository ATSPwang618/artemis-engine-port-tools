# delonhideout

取消使用 setonhideout 设置的事件处理程序。