# delonpush

取消使用 setonpush 设置的事件处理程序。

```
key
	NUMBER
		要移除分配的键的键ID
		键ID请参阅 spec/key_id.xls
```