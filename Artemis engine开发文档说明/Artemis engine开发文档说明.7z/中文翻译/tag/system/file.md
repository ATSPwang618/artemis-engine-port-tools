# file

执行文件操作。

```
command
	copy
		复制文件
	delete
		删除文件
	clear_cache
		清除打包文件缓存
	wasm_sync
		WASM同步。根据文件列表同步文件系统
		仅适用于WebAssembly。有关详细信息，请参阅WebAssembly文件夹中的readme.txt
	wasm_sync_add_persistent
		在进行WASM同步时注册不删除的文件
	wasm_sync_delete_persistent
		在进行WASM同步时注册要删除的文件
src
	; 当command参数不为copy时将被忽略
	STRING
		源文件的路径
		可以指定包文件内的文件
dst
	; 当command参数不为copy时将被忽略
	STRING
		目标文件的路径
target
	; 当command参数不为delete、wasm_sync_add_persistent、
	; wasm_sync_delete_persistent时将被忽略
	STRING
		command="delete"时，要删除的文件的路径
		command="wasm_sync_add_persistent"时，
		要注册的文件的相对路径，以 ./ 开始
		command="wasm_sync_delete_persistent"时，
		要删除注册的文件的相对路径，以 ./ 开始
url
	; 当command参数不为wasm_sync时将被忽略
	STRING
		要同步的文件列表的URL
baseurl
	; 当command参数不为wasm_sync时将被忽略
	STRING
		要同步的文件的基准URL
list
	; 当command参数不为wasm_sync时将被忽略
	STRING ARRAY
		要同步的文件列表
```