# setonautomodeout

设置自动模式的结束事件处理程序。

```
file
	; lyevent 标签的 file 参数相同
label
	; lyevent 标签的 label 参数相同
call
	; lyevent 标签的 call 参数相同
handler
	; lyevent 标签的 handler 参数相同
```