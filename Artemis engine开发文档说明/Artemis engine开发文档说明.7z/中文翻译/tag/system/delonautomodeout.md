# delonautomodeout

取消使用 setonautomodeout 设置的事件处理程序。
