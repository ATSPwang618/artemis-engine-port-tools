# httpget

执行 HTTP GET 请求，指定 URL 进行网络访问。

```
url
	STRING
		URL
header_key0
	STRING
		要附加的额外标头的键
	缺省
		不添加额外的标头
header_value0
	STRING
		要附加的额外标头的值
	缺省
		不添加额外的标头
varname_code
	STRING
		存储响应代码的变量名称
varname_data
	; 如果指定了filename参数，则忽略此参数
	STRING
		存储结果的变量名称
filename
	STRING
		将结果存储到文件而不是变量中
	缺省
		将结果存储到指定为varname_data参数的变量中
```

header_key0 和 header_value0 可以指定多个，例如：

```
[httpget
	url="http://www.ies-net.com/"
	header_key0="foo"
	header_value0="bar"
	header_key1="hoge"
	header_value1="fuga"
]
```

在执行httpget期间，如果在Lua的每帧处理中设置系统变量 s.http.cancel 为 1，
则会中断访问处理并立即结束标记的执行。

在WebAssembly中，需要考虑CORS（跨源资源共享）。
