# delondirchg

取消使用 setondirchg 设置的事件处理程序。