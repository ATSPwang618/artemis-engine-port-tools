# openbrowser

使用设备上安装并默认设置的浏览器打开 URL。

```
url
	STRING
		要打开的 URL。
```

在 WebAssembly 中，这可能会受到许多浏览器的弹出窗口拦截器的影响。
要避免这种情况，可以使用 Lua 中的 e:setEventHandler{ onInputEvent = "" }。
