# purchase

进行应用内购买。
仅适用于 iOS 和 Android。

### 通用部分

```
purchase
	0
		仅获取购买项目信息，而不执行购买流程
	缺省, 1
		执行购买流程
varname
	STRING
		结果存储变量的名称
```

### iOS

```
productid
	STRING
		购买项目的 ID
restore
	缺省, 0
		不执行恢复流程
	1
		执行恢复流程
		purchase 参数将被忽略
```

存储在由 varname 参数指定的变量中的值取决于是否执行了恢复流程。

通常情况如下：
```
(假设 varname="result")
  result -> 结果代码
  result.title -> 购买项目名称
  result.description -> 购买项目描述
  result.price -> 价格（包括货币符号和逗号）
  result.receipt -> 用于在自定义服务器上验证购买的收据数据
```

对于恢复流程，存储在变量中的信息如下：
```
(假设 varname="result")
  result.0 -> 恢复的购买项目的 ID
  result.1 -> 恢复的购买项目的 ID
  result.size -> 2
```

### Android

```
key
	STRING
		可在 Google Play Developer Console 中获得的许可密钥
sku
	STRING
		购买项目的 ID
consume
	缺省, 0
		不执行消耗流程
	1
		执行消耗流程
```

存储在由 varname 参数指定的变量中的值如下：
```
(假设 varname="result")
  result -> 结果代码
  result.title -> 购买项目名称
  result.description -> 购买项目描述
  result.price -> 价格（包括货币符号和逗号）
  result.token -> 用于在自定义服务器上验证购买的令牌
  result.error_response -> In App Billing 库 (IabHelper) 返回的错误号码
  result.error_message -> In App Billing 库 (IabHelper) 返回的错误消息
```