# deloncontrolskipin

取消使用 setoncontrolskipin 设置的事件处理程序。