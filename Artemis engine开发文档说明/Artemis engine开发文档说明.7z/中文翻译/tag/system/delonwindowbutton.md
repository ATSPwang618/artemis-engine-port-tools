# delonwindowbutton

取消使用 setonwindowbutton 设置的事件处理程序。

```
button
	0
		关闭按钮 (×按钮)
	1
		最大化按钮
	2
		最小化按钮
	缺省
		由于是遗留功能，已不推荐使用
```