# caption

设置窗口标题栏的字符串。
仅适用于 Windows。

```
data
	STRING
		标题字符串
```