# delonbacklogout

取消使用 setonbacklogout 设置的事件处理程序。