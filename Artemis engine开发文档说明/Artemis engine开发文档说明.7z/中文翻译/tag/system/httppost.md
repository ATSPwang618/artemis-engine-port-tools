# httppost

执行 HTTP POST 请求，指定 URL 进行网络访问。

```
url
	; httpget标签的url参数相同
header_key0
	; httpget标签的header_key0参数相同
header_value0
	; httpget标签的header_value0参数相同
key0
	STRING
		要附加的POST数据的键
	缺省
		不添加额外的POST数据
value0
	STRING
		要附加的POST数据的值
	缺省
		不添加额外的POST数据
file0
	PATH
		要用作附加的POST数据值的文件的路径
	缺省
		不添加额外的POST数据
varname_code
	; httpget标签的varname_code参数相同
varname_data
	; httpget标签的varname_data参数相同
filename
	; httpget标签的filename参数相同
```

请参考httpget标签的说明。

key0、value0和file0可以指定多个，例如：

```
[httppost
	url="http://www.ies-net.com/"
	key0="foo"
	value0="bar"
	key1="hoge"
	file1="fuga"
]
```

在WebAssembly中，需要考虑CORS（跨源资源共享）。
另外，无法使用file0参数。
