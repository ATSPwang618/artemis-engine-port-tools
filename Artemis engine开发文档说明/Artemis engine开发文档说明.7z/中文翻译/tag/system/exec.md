# exec

通常情况下，从脚本执行各种用户操作。

```
command
	rclick
		右键单击
	automode
		自动模式
		如果不指定mode参数，则开始自动模式
	skip
		跳过
		如果不指定mode参数，则为切换操作
		（如果不在跳过状态，则开始跳过，如果在跳过状态，则停止跳过）
	hide
		隐藏
	backlog
		日志
	fullscreen
		全屏模式
		如果已经是全屏状态，则切换回窗口模式
		仅适用于Windows
	minimize
		最小化
		如果已经最小化，则取消最小化
		仅适用于Windows
mode
	; 仅当command参数为automode或skip时才能指定
	0
		停止自动模式或跳过
	1
		开始自动模式或跳过
	缺省
		执行默认操作
```