# deloncontrolskipout

取消使用 setoncontrolskipout 设置的事件处理程序。