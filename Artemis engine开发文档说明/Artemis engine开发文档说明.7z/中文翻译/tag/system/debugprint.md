# debugprint

输出日志。

```
level
	0...3
		只有 debug 标签的级别设置高于此值时才会输出。
data
	STRING
		要输出的字符串。
```