# delonautomodein

取消使用 setonautomodein 设置的事件处理程序。
