# setondirchg

设置屏幕方向变更事件处理程序。

仅适用于iOS。

```
file
	; lyevent 标签的 file 参数相同
label
	; lyevent 标签的 label 参数相同
call
	; lyevent 标签的 call 参数相同
handler
	; lyevent 标签的 handler 参数相同
```

当事件处理程序被调用时，
系统变量 `s.status.screendirectio`n 将设置为当前方向，
`s.status.screendirectionprevious` 将设置为先前的方向。

```
0
	纵向
1
	横向，Home按钮在右侧
2
	倒置的纵向
3
	横向，Home按钮在左侧
```