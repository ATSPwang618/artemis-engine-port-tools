# var system="var_exist"

检查变量是否存在。

```
name
	STRING
		值的存储变量名称
target
	STRING
		要检查的变量名称
local
	缺省, 0
		检查目标是所有变量
	1
		检查目标是作为宏参数传递的变量
```