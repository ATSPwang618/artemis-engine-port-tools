# var system="url_encode"

将字符串进行 URL 编码。

```
name
	STRING
		值的存储变量名称
source
	STRING
		目标字符串
```