# var system="convert_encoding"

将字符串的字符编码进行转换。

```
name
	STRING
		存储值的变量名称
source
	STRING
		目标字符串
from
	; 源字符编码
	sjis
		Shift_JIS
	euc
		EUC-JP
	jis
		JIS
	utf8
		UTF-8
	缺省
		尝试自动识别源字符编码
		对于较短的字符串等情况，自动识别可能会失败
to
	; 目标字符编码
	sjis
		Shift_JIS
	euc
		EUC-JP
	jis
		JIS
	utf8
		UTF-8
```