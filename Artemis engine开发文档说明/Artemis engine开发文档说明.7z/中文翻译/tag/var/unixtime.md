# var system="unixtime"

获取 UNIX 时间。

```
name
	STRING
		值的存储变量名称
```