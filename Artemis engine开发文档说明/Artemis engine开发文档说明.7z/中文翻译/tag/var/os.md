# var system="os"

获取操作系统信息。

```
name
	STRING
		存储值的变量名称
```

根据不同的平台：
```
  Windows -> windows
  iOS -> iphone
  Android -> android
  WebAssembly -> webassembly
```