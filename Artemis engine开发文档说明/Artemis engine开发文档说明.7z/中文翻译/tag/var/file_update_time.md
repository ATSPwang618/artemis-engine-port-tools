# var system="file_update_time"

获取保存文件的更新日期和时间。

```
name
	STRING
		存储值的变量名称
file
	PATH
		目标保存文件的路径
format
	STRING
		日期时间获取格式
		年份可以使用 yyyy 或 yy（最后两位数）
		月日时分秒可以使用 MM dd hh mm ss 或 M d h m s（不补零）
	缺省
		使用 yyyy/MM/dd hh:mm:ss
noexist
	STRING
		文件不存在时返回的字符串
```