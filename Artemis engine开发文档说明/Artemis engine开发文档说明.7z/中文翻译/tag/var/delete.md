# var system="delete"

删除变量。

```
name
	STRING
		要删除的变量名称
	缺省
		删除所有变量
```

可以通过指定以点分隔的变量组的父项来一次性删除整个变量组，包括子项。

例如，如果有三个变量 foo.bar、foo.hoge 和 foo.fuga，
执行 `var name="foo" system="delete"` 后，这三个变量都会被删除。

但是，请注意，如果还有 foo 本身存在，
第一次删除将删除 foo 本身，
第二次删除将删除 foo.~ 下的每个变量。
