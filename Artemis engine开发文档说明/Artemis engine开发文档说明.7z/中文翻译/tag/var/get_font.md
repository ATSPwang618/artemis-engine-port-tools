# var system="get_font"

获取系统中安装的字体列表。
仅适用于Windows。

```
name
	STRING
		存储值的变量名称
monospace
	缺省, 0
		获取所有字体
	1
		仅获取等宽字体
vertical
	缺省, 0
		获取横排字体
	1
		获取竖排字体
```

结果将以伪数组形式返回。
有关伪数组形式的详细信息，请参阅implode标签。
