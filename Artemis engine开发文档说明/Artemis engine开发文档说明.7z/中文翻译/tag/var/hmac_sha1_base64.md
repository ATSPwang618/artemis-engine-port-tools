# var system="hmac_sha1_base64"

使用指定的密钥计算字符串的HMAC-SHA1，并获取其BASE64编码。

```
name
	STRING
		存储值的变量名称
message
	STRING
		目标字符串
key
	STRING
		密钥
```