# var system="explode"

将字符串按分隔符分割，并存储到伪数组形式的变量中。

```
name
	STRING
		存储值的变量名称
source
	STRING
		目标字符串
delimiter
	STRING
		分隔符
	缺省
		默认分隔符为逗号
escape
	STRING
		转义序列
	缺省
		默认转义序列为反斜杠
```

例如，如果有字符串 "bar,hoge,fuga"，
执行 
```
[var name="foo" data="bar,hoge,fuga"]
[var name="result" system="explode"] 
```
后，
```
foo.0 的值为 bar
foo.1 的值为 hoge
foo.2 的值为 fuga
foo.size 的值为 3
```