# var system="substr"

截取字符串的一部分。

```
name
	STRING
		值的存储变量名称
source
	STRING
		目标字符串
position
	NUMBER
		截取开始位置
length
	NUMBER
		长度
mode
	缺省, 0
		将position参数和length参数视为字节长度
		如果不考虑多字节字符，可能会在字符中间错误地分割
	1
		将position参数和length参数视为字符数
```