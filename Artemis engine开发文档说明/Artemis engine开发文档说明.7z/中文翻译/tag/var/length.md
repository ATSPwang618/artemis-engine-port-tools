# var system="length"

获取字符串的长度。
长度以字节计，而不是字符计数。

```
name
	STRING
		存储值的变量名称
source
	STRING
		目标字符串
mode
	默认值, 0
		获取字节长度
		在 Shift_JIS 模式下，多字节字符计为 2
		在 UTF-8 模式下，多字节字符计为 2～6（日语中许多字符计为 3）
	1
		获取字符数
```