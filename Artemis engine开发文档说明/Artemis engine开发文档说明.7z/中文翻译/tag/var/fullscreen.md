# var system="fullscreen"

获取当前是否处于全屏模式。
仅适用于Windows。

```
name
	STRING
		存储值的变量名称
```

如果是全屏模式，则存储为 1，如果是窗口模式，则存储为 0。
