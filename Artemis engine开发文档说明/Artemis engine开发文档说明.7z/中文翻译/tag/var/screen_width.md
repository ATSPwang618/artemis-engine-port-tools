# var system="screen_width"

获取system.ini中指定的舞台大小的宽度。

```
name
	STRING
		值的存储变量名称
```