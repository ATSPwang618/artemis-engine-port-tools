### var system="get_layer_info"

获取设置在图层属性中的值。

```
name
	STRING
		值的存储变量名称
id
	STRING
		目标图层的ID
	缺省
		获取所有图层的信息
style
	; 如果省略了id参数，则此参数将被忽略
	map
		以伪关联数组形式获取
	缺省
		以伪数组形式获取
```

当存在图层时，例如：
```
[lyc id="foo" file="foo"]
[lyc id="bar" file="bar"]
[lyc id="hoge" file="hoge"]
[lyprop id="foo" left="100"]
[lyprop id="bar" top="100"]
[lyprop id="hoge" alpha="128"]
```
执行以下操作：
```
[var name="result" system="get_layer_info"]
```
将得到：
```
  result.0.id -> bar
  result.0.top -> 100
  result.1.id -> foo
  result.1.left -> 100
  result.2.id -> hoge
  result.2.alpha -> 128
  result.size -> 3
等等（其他属性类似）。
```

执行以下操作：
```
[var name="result" system="get_layer_info" style="map"]
```
将得到：
```
  result.bar.top -> 100
  result.foo.left -> 100
  result.hoge.alpha -> 128
等等（其他属性类似）。
```
执行以下操作：
```
[var name="result" system="get_layer_info" id="foo"]
```
将得到：
```
  result.left -> 100
等等（其他属性类似）。
```