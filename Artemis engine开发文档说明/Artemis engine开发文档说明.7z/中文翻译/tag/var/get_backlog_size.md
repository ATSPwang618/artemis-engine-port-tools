# var system="get_backlog_size"

获取内置回溯日志中存储的页面数。

```
name
	STRING
		存储值的变量名称
```