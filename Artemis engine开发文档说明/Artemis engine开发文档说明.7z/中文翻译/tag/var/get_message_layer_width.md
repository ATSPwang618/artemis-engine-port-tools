# var system="get_message_layer_width"

获取绘制当前消息图层中存储的文本时的整体宽度。

```
name
	STRING
		值的存储变量名称
```