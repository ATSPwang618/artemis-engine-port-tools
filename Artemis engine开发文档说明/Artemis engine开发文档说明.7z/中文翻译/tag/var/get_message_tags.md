# var system="get_message_tags"

获取当前显示的情节文本所需的标记，以便再现。

```
name
	STRING
		值的存储变量名称
id
	STRING
		目标消息图层的ID
allfont
	缺省, 0
		不包括用于复制页面初始时刻的字体标记
	1
		包括用于复制页面初始时刻的字体标记
```

结果以适用于tag标记的伪数组形式返回，请参阅implode标记了解伪数组的详细信息。
