# var system="file_exists"

检查文件是否存在。可以检查打包文件的内容。

```
name
	STRING
		存储值的变量名称
file
	PATH
		目标文件的路径
save
	缺省, 0
		目标为普通文件
	1
		目标为保存数据
```