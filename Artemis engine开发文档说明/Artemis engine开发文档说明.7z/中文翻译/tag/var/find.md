# var system="find"

在字符串中查找另一个字符串，并返回字符串出现的位置。
位置以字节计算。

```
name
	STRING
		存储值的变量名称
source
	STRING
		目标字符串
string
	STRING
		搜索的字符串
```