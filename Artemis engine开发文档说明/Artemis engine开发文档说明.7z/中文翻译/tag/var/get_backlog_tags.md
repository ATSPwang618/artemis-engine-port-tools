# var system="get_backlog_tags"

获取内置回溯日志中存储的每个页面所需的标签集，以便再现。

```
name
	STRING
		存储值的变量名称
page
	NUMBER
		目标页面的页码
allfont
	缺省, 0
		不包括用于再现页面开头字体的font标签
	1
		包括用于再现页面开头字体的font标签
```

结果以伪数组形式返回，可以通过tag标签执行。有关伪数组的更多信息，请参阅implode标签。
