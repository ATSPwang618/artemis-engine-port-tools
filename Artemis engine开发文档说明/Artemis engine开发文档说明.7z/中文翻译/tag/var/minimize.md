# var system="minimize"

获取当前窗口是否处于最小化状态。
仅适用于Windows。

```
name
	STRING
		存储值的变量名称
```

如果窗口处于最小化状态，则存储为1，否则存储为0。
