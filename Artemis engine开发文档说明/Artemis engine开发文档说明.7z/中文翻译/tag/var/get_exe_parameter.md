# var system="get_exe_parameter"

获取exe文件的启动参数。
仅适用于Windows。

```
name
	STRING
		存储值的变量名称
```

结果将如下所示获取：

例如，
  `Artemis.exe /a foo /b bar`
启动后，
```
  [var name="test" system="get_exe_parameter"]
```
将得到：
```
  test.a -> foo
  test.b -> bar
```

注意，您也可以使用连字符代替斜杠。
```
  Artemis.exe -a foo -b bar
```
