# var system="get_message_layer_line_width"

获取绘制当前消息图层中存储的文本时最后一行的宽度。

```
name
	STRING
		值的存储变量名称
```