# var system="implode"

推荐使用 Lua。

将存储在伪数组形式变量组中的字符串连接成一个用指定分隔符分隔的字符串。

```
name
	STRING
		存储值的变量名称
source
	STRING
		伪数组形式变量的名称
delimiter
	STRING
		分隔符
	默认值
		逗号作为分隔符
```

伪数组形式是指以下形式的变量：

```
[var name="foo.0" data="bar"]
[var name="foo.1" data="hoge"]
[var name="foo.2" data="fuga"]
[var name="foo.size" data="3"]
[var name="result" system="implode" source="foo"]
```

执行后，result 变量的值为 bar,hoge,fuga。
