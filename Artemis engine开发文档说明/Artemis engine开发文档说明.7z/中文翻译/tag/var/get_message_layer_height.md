# var system="get_message_layer_height"

获取当前消息图层中绘制文本时的总高度。

```
name
	STRING
		值的存储变量名称
```