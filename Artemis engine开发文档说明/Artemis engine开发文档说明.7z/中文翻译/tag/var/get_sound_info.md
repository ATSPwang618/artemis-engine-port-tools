# var system="get_sound_info"

获取声音的播放状态。

```
name
	STRING
		值的存储变量名称
id
	STRING
		目标SE的ID
	缺省
		获取BGM和所有SE的信息
```

例如，当存在声音时：
```
[splay file="foo" gain="500"]
[seplay id="bar" file="bar" pan="-500"]
[seplay id="hoge" file="hoge" pan="500"]
```
然后执行：
```
[var name="result" system="get_sound_info"]
```
将返回：
```
  result.playing -> 1
  result.gain -> 500
  result.pan -> 0
  result.0.id -> bar
  result.0.playing -> 1
  result.0.gain -> 1000
  result.0.pan -> -500
  result.1.id -> hoge
  result.1.playing -> 1
  result.1.gain -> 1000
  result.1.pan -> 500
  result.size -> 2
```
再执行：
```
[var name="result" system="get_sound_info" id="bar"]
```
将返回：
```
  result.playing -> 1
  result.gain -> 1000
  result.pan -> -500
```
再执行：
```
[var name="result" system="get_sound_info" id="nothing"]
```
将返回：
```
  result.playing -> 0
```