# var

将值存储到变量中。

由于此标签根据设置的system参数值执行不同的操作，因此具有针对不同值的不同参考文档。

本文件是省略了system参数的默认情况。

```
name
	STRING
		存储值的变量名称
data
	; 指定此参数将忽略system参数
	STRING
		要存储的值
```