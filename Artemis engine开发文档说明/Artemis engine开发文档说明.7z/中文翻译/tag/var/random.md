# var system="random"

生成随机数。

```
name
	STRING
		值的存储变量名称
min
	NUMBER
		生成的随机数的最小值
	缺省
		不指定最小值
max
	NUMBER
		生成的随机数的最大值
	缺省
		不指定最大值
```