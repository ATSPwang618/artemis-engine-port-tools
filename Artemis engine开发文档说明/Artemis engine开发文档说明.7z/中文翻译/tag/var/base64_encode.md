# var system="base64_encode"

该指令用于对字符串进行BASE64编码。

```
name
	STRING
		用于存储值的变量名称
source
	STRING
		目标字符串
```