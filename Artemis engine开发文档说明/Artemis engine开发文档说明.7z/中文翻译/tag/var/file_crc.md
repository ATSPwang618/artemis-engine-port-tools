# var system="file_crc"

获取文件的 CRC。

```
name
	STRING
		存储值的变量名称
file
	PATH
		目标文件的路径
zerox
	缺省, 0
		不添加 0x 前缀
	1
		添加 0x 前缀
caps
	缺省, 0
		转换为小写
	1
		转换为大写
```