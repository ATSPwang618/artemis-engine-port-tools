# var system="date"

获取当前日期和时间。

```
name
	STRING
		存储值的变量名称
```

使用 `[var name="result" system="date"]`，则可以获得以下值：
```
  result.year -> 年
  result.month -> 月
  result.day -> 日
  result.hour -> 时
  result.minute -> 分
  result.second -> 秒
```