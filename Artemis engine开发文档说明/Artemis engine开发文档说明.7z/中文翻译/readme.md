Artemis Engine 文档

Artemis Engine 官方文档的中文翻译。

大部分内容使用 AI 翻译，但因为我自己也阅读该文档进行开发，大部分内容都经过中日对照后人工校正。

但并非所有标签我都会使用，因此标签和 Lua 部分可能会有翻译不一致的地方，欢迎提交 PR 更正

## 简介

+ [按键分配（操作方法）](./spec/key_assign.md)
+ [图层](./spec/layer.md)
+ [宏](./spec/macro.md)
+ [pfs包文件](./spec/pack_file.md)
+ [运行环境与开环境](./spec/requirement.md)
+ [脚本语法](./spec/script_syntax.md) 施工中
+ [启动设置文件 system_ini](./spec/system_ini.md)
+ [系统变量](./spec/system_variables.md)

> [按键代码列表](./spec/key_id.md) 

## 标签参考

请务必先阅读 [标签参考的使用方式](./tag/readme.md)

### 剧情脚本（scenario）
+ [alreadyread](./tag/scenario/alreadyread.md): 设置是否进行已读未读判定。
+ [automode](./tag/scenario/automode.md): 设置自动模式。
+ [backlog](./tag/scenario/backlog.md): 设置历史文本。
+ [chgmsg](./tag/scenario/chgmsg.md): 切换当前消息层。
+ [chgmsg_close](./tag/scenario/chgmsg_close.md): 将当前消息层回退到消息层堆栈中存储的最后一个消息层。
+ [font](./tag/scenario/font.md): 用于设置当前消息层的字体设置。
+ [font_close](./tag/scenario/font_close.md): 当前消息图层的字体设置将被回滚到最后存储在字体堆栈中的设置。
+ [fontdefault](./tag/scenario/fontdefault.md): 定义字体的默认设置。
+ [fontinit](./tag/scenario/fontinit.md): 将当前消息层的字体设置更改为由fontdefault标签设置的默认设置。
+ [glyph](./tag/scenario/glyph.md): 设置点击等待图标。
+ [hide](./tag/scenario/hide.md): 设置隐藏（用户临时隐藏消息层）。
+ [indent](./tag/scenario/indent.md): “对话的第一行的开头是尖括号。
+ [link](./tag/scenario/link.md): 设置在剧情文本中创建链接。
+ [linkdisable](./tag/scenario/linkdisable.md): 将使用link标签设置的链接暂时禁用。
+ [linkenable](./tag/scenario/linkenable.md): 使用link标签设置，并且通过linkdisable标签暂时禁用的链接，
+ [print](./tag/scenario/print.md): 显示场景文本。
+ [prohibit](./tag/scenario/prohibit.md): 设置禁则处理的字符。
+ [rp](./tag/scenario/rp.md): 将场景文本分页。
+ [rt](./tag/scenario/rt.md): 将场景文本换行。
+ [ruby](./tag/scenario/ruby.md): 在ruby标签和/ruby标签中间的文本上添加注音。
+ [scein](./tag/scenario/scein.md): 将使用sceout隐藏的场景文本还原显示。
+ [sceout](./tag/scenario/sceout.md): 对场景文本进行改页的动画处理。
+ [scetween](./tag/scenario/scetween.md): 设置场景文本的动画效果。
+ [skip](./tag/scenario/skip.md): 设置跳过功能。
+ [wordparts](./tag/scenario/wordparts.md): 设置被视为单词部分的字符，以防止单词中途换行。
+ [writebacklog](./tag/scenario/writebacklog.md): 设置是否将场景文本存入历史。
+ ~~[ime](./tag/scenario/ime.md)~~

### 程序脚本（script）
+ [call](./tag/script/call.md): 将脚本的执行位置存储到调用栈中，然后进行更改。
+ [else](./tag/script/else.md): 参考 if 标签
+ [elseif](./tag/script/elseif.md): 请参考if标签。
+ [if](./tag/script/if.md): 执行条件分支。
+ [jump](./tag/script/jump.md): 更改脚本的执行位置。
+ [loop](./tag/script/loop.md): 执行循环操作。
+ [macroadd](./tag/script/macroadd.md): 添加要用作宏定义的文件，默认情况下只有 macro.iet。
+ [macrodel](./tag/script/macrodel.md): 取消作为宏定义的文件，不再将其视为宏定义文件。
+ [rclick](./tag/script/rclick.md): 设置右键单击脚本。
+ [return](./tag/script/return.md): 将执行位置更改为存储在调用栈中的最后位置。
+ [stop](./tag/script/stop.md): 停止脚本的执行。
+ [tag](./tag/script/tag.md): 执行任意的标签。
+ [wait](./tag/script/wait.md): 暂时停止脚本的执行。

### 图像/视频相关
+ [anime](./tag/graphics/anime.md): 简单地将多个图像文件连续显示在一起，加载到图层中以创建简单的动画。
+ [delonvideofinish](./tag/graphics/delonvideofinish.md): 释放使用 setonvideofinish 设置的事件处理程序。
+ [flip](./tag/graphics/flip.md): 它与 trans type="0" 的效果几乎相同，但不会退出脚本执行循环。
+ [lyc](./tag/graphics/lyc.md): 将图像加载到图层中。
+ [lydel](./tag/graphics/lydel.md): 删除图层
+ [lydrag](./tag/graphics/lydrag.md): 将图层强制设置为拖动状态。
+ [lyedit](./tag/graphics/lyedit.md): 对图层中加载的图像进行加工。
+ [lyevent](./tag/graphics/lyevent.md): 设置图层的事件处理程序。
+ [lyprop](./tag/graphics/lyprop.md): 设置图层的属性。
+ [lyrename](./tag/graphics/lyrename.md): 更改图层的ID。
+ [lytween](./tag/graphics/lytween.md): 设置图层属性连续变化的“缓动”效果。
+ [lytweendel](./tag/graphics/lytweendel.md): 强制完成由lytween标签设置的缓动。
+ [savess](./tag/graphics/savess.md): 将由takess拍摄的屏幕截图保存为PNG文件。
+ [setonvideofinish](./tag/graphics/setonvideofinish.md): 设置视频图层播放完成事件处理程序。
+ [takess](./tag/graphics/takess.md): 拍摄屏幕截图。
+ [trans](./tag/graphics/trans.md): 从当前图层树向未来图层树进行画面过渡（转换）。
+ [tweenset](./tag/graphics/tweenset.md): 将多个lytween标签用tweenset标签和/tweenset标签包围起来，以便按顺序执行这些动画。
+ [video](./tag/graphics/video.md): 播放全屏视频或创建视频图层。
+ ~~[delonclick](./tag/graphics/delonclick.md)~~
+ ~~[delondrag](./tag/graphics/delondrag.md)~~
+ ~~[delondragin](./tag/graphics/delondragin.md)~~
+ ~~[delondragout](./tag/graphics/delondragout.md)~~
+ ~~[delonrollout](./tag/graphics/delonrollout.md)~~
+ ~~[delonrollover](./tag/graphics/delonrollover.md)~~
+ ~~[setonclick](./tag/graphics/setonclick.md)~~
+ ~~[setondrag](./tag/graphics/setondrag.md)~~
+ ~~[setondragin](./tag/graphics/setondragin.md)~~
+ ~~[setondragout](./tag/graphics/setondragout.md)~~
+ ~~[setonrollout](./tag/graphics/setonrollout.md)~~
+ ~~[setonrollover](./tag/graphics/setonrollover.md)~~


### 音频相关
+ [delonsoundfinish](./tag/sound/delonsoundfinish.md): 解除使用setonsoundfinish设置的事件处理程序。
+ [sefade](./tag/sound/sefade.md): 更改SE的增益。
+ [sepan](./tag/sound/sepan.md): 更改SE的声像。
+ [seplay](./tag/sound/seplay.md): 播放SE。
+ [sestop](./tag/sound/sestop.md): 停止SE的播放。
+ [setonsoundfinish](./tag/sound/setonsoundfinish.md): 设置声音播放完成事件处理程序。
+ [sfade](./tag/sound/sfade.md): 更改BGM的增益。
+ [span](./tag/sound/span.md): 更改BGM的声像。
+ [splay](./tag/sound/splay.md): 播放BGM。
+ [sstop](./tag/sound/sstop.md): 停止BGM。
+ [sxfade](./tag/sound/sxfade.md): 交叉淡入BGM。
+ [voice](./tag/sound/voice.md): 与seplay几乎相同，但如果在带有声音的台词周围使用voice标签和/voice标签，将在内置的后台日志中显示文本链接，
+ ~~[sefadein](./tag/sound/sefadein.md)~~
+ ~~[sefadeout](./tag/sound/sefadeout.md)~~
+ ~~[sfadein](./tag/sound/sfadein.md)~~
+ ~~[sfadeout](./tag/sound/sfadeout.md)~~

### 变量
+ [base64_encode](./tag/var/base64_encode.md): 该指令用于对字符串进行BASE64编码。
+ [character_reference_to_utf8](./tag/var/character_reference_to_utf8.md): 将字符引用的字符串转换为UTF-8字符串。
+ [convert_encoding](./tag/var/convert_encoding.md): 将字符串的字符编码进行转换。
+ [date](./tag/var/date.md): 获取当前日期和时间。
+ [delete](./tag/var/delete.md): 删除变量。
+ [explode](./tag/var/explode.md): 将字符串按分隔符分割，并存储到伪数组形式的变量中。
+ [file_crc](./tag/var/file_crc.md): 获取文件的 CRC。
+ [file_exists](./tag/var/file_exists.md): 检查文件是否存在。可以检查打包文件的内容。
+ [file_update_time](./tag/var/file_update_time.md): 获取保存文件的更新日期和时间。
+ [find](./tag/var/find.md): 在字符串中查找另一个字符串，并返回字符串出现的位置。
+ [fullscreen](./tag/var/fullscreen.md): 获取当前是否处于全屏模式。
+ [get_backlog_size](./tag/var/get_backlog_size.md): 获取内置回溯日志中存储的页面数。
+ [get_backlog_tags](./tag/var/get_backlog_tags.md): 获取内置回溯日志中存储的每个页面所需的标签集，以便再现。
+ [get_exe_parameter](./tag/var/get_exe_parameter.md): 获取exe文件的启动参数。
+ [get_font](./tag/var/get_font.md): 获取系统中安装的字体列表。
+ [get_layer_info](./tag/var/get_layer_info.md): 获取设置在图层属性中的值。
+ [get_message_layer_height](./tag/var/get_message_layer_height.md): 获取当前消息图层中绘制文本时的总高度。
+ [get_message_layer_line_width](./tag/var/get_message_layer_line_width.md): 获取绘制当前消息图层中存储的文本时最后一行的宽度。
+ [get_message_layer_width](./tag/var/get_message_layer_width.md): 获取绘制当前消息图层中存储的文本时的整体宽度。
+ [get_message_tags](./tag/var/get_message_tags.md): 获取当前显示的情节文本所需的标记，以便再现。
+ [get_sound_info](./tag/var/get_sound_info.md): 获取声音的播放状态。
+ [hmac_sha1_base64](./tag/var/hmac_sha1_base64.md): 使用指定的密钥计算字符串的HMAC-SHA1，并获取其BASE64编码。
+ [implode](./tag/var/implode.md): 推荐使用 Lua。
+ [length](./tag/var/length.md): 获取字符串的长度。
+ [minimize](./tag/var/minimize.md): 获取当前窗口是否处于最小化状态。
+ [os](./tag/var/os.md): 获取操作系统信息。
+ [random](./tag/var/random.md): 生成随机数。
+ [screen_height](./tag/var/screen_height.md): 获取system.ini中指定的舞台大小的高度。
+ [screen_width](./tag/var/screen_width.md): 获取system.ini中指定的舞台大小的宽度。
+ [substr](./tag/var/substr.md): 截取字符串的一部分。
+ [unixtime](./tag/var/unixtime.md): 获取 UNIX 时间。
+ [url_decode](./tag/var/url_decode.md): 将字符串进行 URL 解码。
+ [url_encode](./tag/var/url_encode.md): 将字符串进行 URL 编码。
+ [var](./tag/var/var.md): 将值存储到变量中。
+ [var_exist](./tag/var/var_exist.md): 检查变量是否存在。
+ ~~[file_exist](./tag/var/file_exist.md)~~
+ ~~[to_sjis](./tag/var/to_sjis.md)~~
+ ~~[to_utf8](./tag/var/to_utf8.md)~~

### 系统
+ [autosave](./tag/system/autosave.md): 设置自动保存。
+ [avoid](./tag/system/avoid.md): 设置紧急回避功能。
+ [calllua](./tag/system/calllua.md): 执行 Lua 函数。
+ [callnative](./tag/system/callnative.md): 执行非 Artemis 脚本或 Lua 脚本的原生代码。
+ [caption](./tag/system/caption.md): 设置窗口标题栏的字符串。
+ [debug](./tag/system/debug.md): 设置日志输出模式和输出级别。
+ [debugprint](./tag/system/debugprint.md): 输出日志。
+ [debugreload](./tag/system/debugreload.md): 作为调试辅助功能，可以在引擎运行时重新加载脚本。
+ [delonautomodein](./tag/system/delonautomodein.md): 取消使用 setonautomodein 设置的事件处理程序。
+ [delonautomodeout](./tag/system/delonautomodeout.md): 取消使用 setonautomodeout 设置的事件处理程序。
+ [delonbacklogin](./tag/system/delonbacklogin.md): 取消使用 setonbacklogin 设置的事件处理程序。
+ [delonbacklogout](./tag/system/delonbacklogout.md): 取消使用 setonbacklogout 设置的事件处理程序。
+ [deloncommandskipin](./tag/system/deloncommandskipin.md): 取消使用 setoncommandskipin 设置的事件处理程序。
+ [deloncommandskipout](./tag/system/deloncommandskipout.md): 取消使用 setoncommandskipout 设置的事件处理程序。
+ [deloncontrolskipin](./tag/system/deloncontrolskipin.md): 取消使用 setoncontrolskipin 设置的事件处理程序。
+ [deloncontrolskipout](./tag/system/deloncontrolskipout.md): 取消使用 setoncontrolskipout 设置的事件处理程序。
+ [delondirchg](./tag/system/delondirchg.md): 取消使用 setondirchg 设置的事件处理程序。
+ [delonhidein](./tag/system/delonhidein.md): 取消使用 setonhidein 设置的事件处理程序。
+ [delonhideout](./tag/system/delonhideout.md): 取消使用 setonhideout 设置的事件处理程序。
+ [delonpush](./tag/system/delonpush.md): 取消使用 setonpush 设置的事件处理程序。
+ [delonwindowbutton](./tag/system/delonwindowbutton.md): 取消使用 setonwindowbutton 设置的事件处理程序。
+ [dialog](./tag/system/dialog.md): 使用操作系统的功能显示对话框。
+ [exec](./tag/system/exec.md): 通常情况下，从脚本执行各种用户操作。
+ [exit](./tag/system/exit.md): 结束引擎。
+ [file](./tag/system/file.md): 执行文件操作。
+ [httpget](./tag/system/httpget.md): 执行 HTTP GET 请求，指定 URL 进行网络访问。
+ [httppost](./tag/system/httppost.md): 执行 HTTP POST 请求，指定 URL 进行网络访问。
+ [keyconfig](./tag/system/keyconfig.md): 更改按键分配。
+ [load](./tag/system/load.md): 加载存档文件。
+ [lua](./tag/system/lua.md): lua 标签和 /lua 标签之间的部分将作为 Lua 脚本执行。
+ [mouse](./tag/system/mouse.md): 更改鼠标指针的状态。
+ [openbrowser](./tag/system/openbrowser.md): 使用设备上安装并默认设置的浏览器打开 URL。
+ [purchase](./tag/system/purchase.md): 进行应用内购买。
+ [reset](./tag/system/reset.md): 重启引擎
+ [save](./tag/system/save.md): 保存当前执行状态。
+ [setonautomodein](./tag/system/setonautomodein.md): 设置自动模式的开始事件处理程序。
+ [setonautomodeout](./tag/system/setonautomodeout.md): 设置自动模式的结束事件处理程序。
+ [setonbacklogin](./tag/system/setonbacklogin.md): 设置后台日志的开始事件处理程序。
+ [setonbacklogout](./tag/system/setonbacklogout.md): 设置后台日志的结束事件处理程序。
+ [setoncommandskipin](./tag/system/setoncommandskipin.md): 设置跳过开始事件处理程序。
+ [setoncommandskipout](./tag/system/setoncommandskipout.md): 设置跳过结束事件处理程序。
+ [setoncontrolskipin](./tag/system/setoncontrolskipin.md): 设置强制跳过的开始事件处理程序。
+ [setoncontrolskipout](./tag/system/setoncontrolskipout.md): 设置强制跳过的结束事件处理程序。
+ [setondirchg](./tag/system/setondirchg.md): 设置屏幕方向变更事件处理程序。
+ [setonhidein](./tag/system/setonhidein.md): 设置隐藏开始事件处理程序。
+ [setonhideout](./tag/system/setonhideout.md): 设置隐藏结束事件处理程序。
+ [setonpush](./tag/system/setonpush.md): 设置按键输入事件处理程序。
+ [setonwindowbutton](./tag/system/setonwindowbutton.md): 设置窗口按钮按下事件处理程序。
+ [statusbar](./tag/system/statusbar.md): 切换状态栏的显示/隐藏。
+ [vibrate](./tag/system/vibrate.md): 触发设备的振动。
+ ~~[slider](./tag/system/slider.md)~~
+ ~~[uidel](./tag/system/uidel.md)~~

### 预处理
+ [autoinsert](./tag/preprocessor/autoinsert.md): 为脚本上的空行、行头和行尾分配标签。
+ [linetag](./tag/preprocessor/linetag.md): 设置行标签。
+ [scpsupport](./tag/preprocessor/scpsupport.md): 设置脚本输入辅助功能。

## [lua](./lua) 施工中

Lua脚本相关参考