package moe.artemis.gui

import android.app.Activity
import android.app.AlertDialog
import android.view.inputmethod.EditorInfo
import android.widget.EditText

class Dialog(
    private val activity: Activity,
    title: String,
    private val message: String,
    hasCancel: Boolean,
    private val hasInput: Boolean,
    private val ctx: Long
) {
    private var editText: EditText? = null
    private val dialogBuilder: AlertDialog.Builder

    external fun OnClose(type: Int, content: String, context: Long)

    init {
        dialogBuilder = AlertDialog.Builder(activity).apply {
            setTitle(title)
            if (!hasInput) {
                setMessage(message)
            }

            setOnCancelListener {
                OnClose(0, "", ctx)
            }

            setPositiveButton("OK") { _, _ ->
                OnClose(1, editText?.text?.toString() ?: "", ctx)
            }

            if (hasCancel) {
                setNegativeButton("Cancel") { _, _ ->
                    OnClose(0, editText?.text?.toString() ?: "", ctx)
                }
            }
        }

        activity.runOnUiThread {
            if (hasInput) {
                editText = EditText(activity).apply {
                    setSingleLine(true)
                    setText(message)
                    imeOptions = EditorInfo.IME_ACTION_DONE
                }
                dialogBuilder.setView(editText)
            }
            dialogBuilder.show()
        }
    }

    companion object {
        private var instances: HashMap<Int, Dialog> = HashMap()
        private var seed = 0

        @JvmStatic
        fun Show(
            activity: Activity,
            title: String,
            message: String,
            hasCancel: Boolean,
            hasInput: Boolean,
            context: Long
        ): Int {
            seed++
            val dialog = Dialog(activity, title, message, hasCancel, hasInput, context)
            instances.put(seed, dialog)
            return seed
        }

        @JvmStatic
        fun Release(key: Int) {
            instances.remove(key)
        }
    }
}