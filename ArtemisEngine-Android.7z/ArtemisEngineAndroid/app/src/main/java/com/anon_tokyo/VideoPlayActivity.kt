package com.anon_tokyo

import android.app.Activity
import android.content.Intent
import android.content.res.AssetFileDescriptor
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.KeyEvent.KEYCODE_BACK
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.FileDescriptorDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource

class VideoPlayActivity : Activity(), Player.Listener {

    lateinit var player: ExoPlayer
    lateinit var surface: AspectRatioSurfaceView
    var fd: AssetFileDescriptor? = null
    var allowSkip: Int = 0
    var prepared = false
    var pause = false

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prepared = false
        pause = false
        val intent = getIntent()
        val path = intent.getStringExtra("path")
        val offset = intent.getIntExtra("offset", 0)
        val length = intent.getIntExtra("length", 0)
        val volume = intent.getIntExtra("volume", 0)
        allowSkip = intent.getIntExtra("skip", 0)

        if (path.isNullOrBlank() || length <= 0) {
            setResult(0, Intent())
            finish()
            return
        }

        val linearLayout = LinearLayout(this)
        linearLayout.setBackgroundColor(Color.rgb(0, 0, 0))
        linearLayout.gravity = 17
        setContentView(linearLayout, WindowManager.LayoutParams(-1, -1))

        surface = AspectRatioSurfaceView(this)
        surface.setZOrderOnTop(true)
        surface.requestFocus()
        linearLayout.addView(surface)

        player = ExoPlayer.Builder(this).build()
        player.setVideoSurfaceView(surface)
        player.addListener(this)

        if (fd !== null) {
            fd?.close()
        }

        fd = assets.openFd(path)

        val dataSource = DataSource.Factory {
            FileDescriptorDataSource(
                fd!!.fileDescriptor,
                offset + fd!!.startOffset,
                length.toLong()
            )
        }
        val mediaSource: MediaSource = ProgressiveMediaSource.Factory(dataSource)
            .createMediaSource(MediaItem.fromUri(Uri.EMPTY))
        player.setMediaSource(mediaSource)
        player.volume = if (volume >= 1000) {
            1.0f
        } else if (volume <= 0) {
            0.0f
        } else {
            volume / 1000.0f
        }
        player.prepare()
        player.play()
    }

    override fun onResume() {
        super.onResume()
        setSystemUiVisibility(window)
        if (pause) {
            pause = false
            setResult(0, Intent())
            finish()
        }
    }

    override fun onPause() {
        super.onPause()
        player.pause()
        pause = true
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (!this.prepared || this.allowSkip == 0) {
            return super.onTouchEvent(event)
        }
        if (event?.action == MotionEvent.ACTION_DOWN) {
            if (this.allowSkip <= 1) {
                onPlayFinish()
            }
        } else if (event?.action == 261 && this.allowSkip <= 2) {
            onPlayFinish()
        }
        return super.onTouchEvent(event)
    }

    override fun onPlaybackStateChanged(playbackState: Int) {
        when (playbackState) {
            Player.STATE_ENDED -> {
                onPlayFinish()
            }

            Player.STATE_READY -> {
                this.prepared = true
            }

            else -> {}
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
        if (event?.action == 0 && event.keyCode == KEYCODE_BACK && this.allowSkip == 0) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    @OptIn(UnstableApi::class)
    private fun onPlayFinish() {
        setResult(-1, Intent())
        finish()
    }

    @OptIn(UnstableApi::class)
    override fun onDestroy() {
        if (!player.isReleased) {
            player.release()
        }
        if (fd != null) {
            fd?.close()
        }
        super.onDestroy()
    }

    override fun onPlayerError(error: PlaybackException) {
        onPlayFinish()
    }

    override fun onVideoSizeChanged(videoSize: VideoSize) {
        surface.setVideoAspectRatio(videoSize.width.toFloat(), videoSize.height.toFloat())
    }

    override fun finish() {
        super.finish()
        applyCustomAnimations()
    }
}