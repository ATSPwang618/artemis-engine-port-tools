package com.anon_tokyo

import android.content.Intent
import android.util.Log
import android.view.KeyEvent
import com.ies_net.artemis.ArtemisActivity

class GameActivity : ArtemisActivity() {

    public override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    override fun dispatchKeyEvent(keyEvent: KeyEvent): Boolean {
        val keyCode = keyEvent.keyCode
        Log.d("GameActivity", "keyCode=$keyCode")
        if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_ENTER) {
            EmulateKeyEvent(13, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_SHIFT_LEFT) {
            EmulateKeyEvent(115, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_SHIFT_RIGHT) {
            EmulateKeyEvent(115, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_CTRL_LEFT) {
            EmulateKeyEvent(140, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_CTRL_RIGHT) {
            EmulateKeyEvent(140, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_SPACE) {
            EmulateKeyEvent(32, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
            EmulateKeyEvent(37, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            EmulateKeyEvent(38, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
            EmulateKeyEvent(39, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
            EmulateKeyEvent(40, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_A) {
            EmulateKeyEvent(143, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_S) {
            EmulateKeyEvent(83, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_L) {
            EmulateKeyEvent(76, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_V) {
            EmulateKeyEvent(86, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_1) {
            EmulateKeyEvent(112, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_2) {
            EmulateKeyEvent(113, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_3) {
            EmulateKeyEvent(114, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_4) {
            EmulateKeyEvent(115, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_5) {
            EmulateKeyEvent(116, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_6) {
            EmulateKeyEvent(117, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_7) {
            EmulateKeyEvent(118, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_8) {
            EmulateKeyEvent(119, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
            EmulateKeyEvent(13, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_STAR) {
            EmulateKeyEvent(121, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_POUND) {
            EmulateKeyEvent(140, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_C) {
            EmulateKeyEvent(1, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_A) {
            EmulateKeyEvent(139, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_B) {
            EmulateKeyEvent(32, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_X) {
            EmulateKeyEvent(153, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_Y) {
            EmulateKeyEvent(1, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_Z) {
            EmulateKeyEvent(140, 1)
        } else if (keyEvent.action == 1 && keyCode == KeyEvent.KEYCODE_BUTTON_Z) {
            EmulateKeyEvent(140, 0)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_L1) {
            EmulateKeyEvent(83, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_R1) {
            EmulateKeyEvent(76, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_R2) {
            EmulateKeyEvent(152, 2)
        } else if (keyEvent.action == 0 && keyCode == KeyEvent.KEYCODE_BUTTON_THUMBL) {
            EmulateKeyEvent(143, 2)
        }
        return super.dispatchKeyEvent(keyEvent)
    }
}