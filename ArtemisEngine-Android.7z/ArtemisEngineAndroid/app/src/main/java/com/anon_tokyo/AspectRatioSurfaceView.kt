package com.anon_tokyo

import android.content.Context
import android.util.AttributeSet
import android.view.SurfaceView

class AspectRatioSurfaceView : SurfaceView {

    private var videoAspectRatio = 0f

    constructor(context: Context?) : super(context)

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs)

    fun setVideoAspectRatio(width: Float, height: Float) {
        if (width > 0 && height > 0) {
            videoAspectRatio = width / height
            requestLayout()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        var width = MeasureSpec.getSize(widthMeasureSpec)
        var height = MeasureSpec.getSize(heightMeasureSpec)

        if (videoAspectRatio > 0) {
            if (width > height * videoAspectRatio) {
                width = (height * videoAspectRatio).toInt()
            } else {
                height = (width / videoAspectRatio).toInt()
            }
        }
        setMeasuredDimension(width, height)
    }
}