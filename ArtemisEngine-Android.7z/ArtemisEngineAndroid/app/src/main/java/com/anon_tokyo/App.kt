package com.anon_tokyo

import android.app.Application
import android.util.Log
import java.io.File

class App : Application() {

    init {
        System.loadLibrary("artemis")
    }

    override fun onCreate() {
        super.onCreate()
        val file = File(getExternalFilesDir(null), "system_emergency.dat")
        if (file.exists()) {
            Log.d("App.java", "delete(system_emergency.dat)")
            file.delete()
        }
    }
}
