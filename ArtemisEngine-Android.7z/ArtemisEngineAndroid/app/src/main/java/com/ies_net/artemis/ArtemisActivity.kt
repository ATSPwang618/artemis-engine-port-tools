package com.ies_net.artemis

import android.app.NativeActivity
import android.content.Intent
import android.os.Bundle
import com.anon_tokyo.VideoPlayActivity
import com.anon_tokyo.applyCustomAnimations
import com.anon_tokyo.setSystemUiVisibility

open class ArtemisActivity : NativeActivity() {

    external fun OnFinishPurchase(
        result: Int,
        title: String,
        description: String,
        price: String,
        token: String,
        errorResponse: Int,
        errorMessage: String
    )

    external fun OnFinishVideo()

    external fun OnReadyPlayAssetDelivery(assetPaths: String)

    external fun EmulateKeyEvent(key: Int, status: Int)

    external fun ExecuteTag(data: String)

    public override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
    }

    public fun InAppBilling(key: String, sku: String, purchase: Boolean, consume: Boolean) {
        OnFinishPurchase(1, "", "", "", "", 1, "")
    }

    public fun EnablePlayAssetDelivery(names: String) {
        OnReadyPlayAssetDelivery("")
    }

    public fun PlayVideo(filePath: String, offset: Int, length: Int, volume: Int, skip: Int) {
        val intent = Intent(applicationContext, VideoPlayActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        intent.putExtra("path", filePath)
        intent.putExtra("offset", offset)
        intent.putExtra("length", length)
        intent.putExtra("volume", volume)
        intent.putExtra("skip", skip)
        startActivityForResult(intent, 2)
        applyCustomAnimations()
    }

    override fun onResume() {
        super.onResume()
        setSystemUiVisibility(window)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1) {
            if (requestCode == 2) {
                OnFinishVideo()
            }
        } else if (resultCode == 0) {
            finish()
        }
    }
}
