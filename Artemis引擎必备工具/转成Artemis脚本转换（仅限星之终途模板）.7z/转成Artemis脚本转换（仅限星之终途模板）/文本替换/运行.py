import os
import re

# 文件路径
txt_dir = r"C:\Users\26241\Desktop\test\文本替换\原游戏剧本-纯文字"  # .txt 文件所在目录
ast_dir = r"C:\Users\26241\Desktop\test\文本替换\Artemis空白剧本-无文字"  # .ast 文件所在目录
output_dir = r"C:\Users\26241\Desktop\test\文本替换\输出目录"  # 输出目录

# 遍历txt文件并按行读取
for i in range(1, 10):
    txt_file = os.path.join(txt_dir, f"第{i}章.txt")
    ast_file = os.path.join(ast_dir, f"chapter-{i}.ast")
    output_file = os.path.join(output_dir, f"chapter-{i}_modified.ast")

    print(f"正在处理第{i}章...")

    # 读取txt文件的每一行
    with open(txt_file, "r", encoding="utf-8") as f:
        txt_lines = f.readlines()

    # 确保 .txt 文件的行数足够
    if len(txt_lines) < 6:
        print(f"警告: {txt_file} 文件少于6行，可能会导致替换不完全。")

    # 读取ast文件的内容
    with open(ast_file, "r", encoding="utf-8") as f:
        ast_content = f.read()

    # 调试信息：查看原始ast文件的部分内容
    print("原始 AST 内容预览 (部分)：")
    print(ast_content[:300])  # 打印前300个字符以便查看

    # 替换ja部分
    for line_num, line in enumerate(txt_lines, 1):  # 1-based index
        # 处理文本内容，去除首尾空白字符
        line = line.strip()
        if not line:
            continue  # 如果是空行跳过

        # 使用正则表达式构造匹配的占位符
        placeholder = re.escape(f'XXXXXXXXXXXX-文字{line_num}')
        pattern = r'ja = {\{"' + placeholder + r'",\},\},'

        # 构建替换的内容
        replacement = f'ja = {{{{"{line}",}},}},'

        # 输出调试信息：替换的内容和替换位置
        print(f"正在替换: {placeholder} -> {replacement}")

        # 使用正则表达式进行替换
        ast_content = re.sub(pattern, replacement, ast_content)

    # 调试信息：查看修改后的部分内容
    print("修改后的 AST 内容预览 (部分)：")
    print(ast_content[:300])  # 打印前300个字符以便查看

    # 输出到新的文件
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(ast_content)

    print(f"修改后的文件已保存为: {output_file}")

print("所有文件处理完成。")
